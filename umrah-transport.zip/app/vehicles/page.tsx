import type { Metadata } from "next"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import VehicleCard from "@/components/vehicle-card"

export const metadata: Metadata = {
  title: "Our Fleet | Umrah Transport",
  description: "Explore our premium fleet of vehicles for Umrah pilgrims in Saudi Arabia.",
}

// Define vehicles data without JSX elements
const vehiclesData = [
  {
    id: "sedan",
    name: "Luxury Sedan",
    description:
      "Our luxury sedans offer premium comfort for individuals or small groups. Perfect for airport transfers or city travel, these vehicles provide a smooth and elegant transportation experience.",
    capacity: "3 passengers",
    luggage: "3 medium suitcases",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    features: [
      { icon: "thermometer", name: "Climate Control" },
      { icon: "wifi", name: "Free WiFi" },
      { icon: "music", name: "Premium Audio" },
      { icon: "briefcase", name: "Luggage Space" },
      { icon: "users", name: "Professional Driver" },
    ],
    models: ["Mercedes-Benz E-Class", "BMW 5 Series", "Audi A6"],
    price: "Starting from 200 SAR",
  },
  {
    id: "suv",
    name: "Executive SUV",
    description:
      "Our executive SUVs combine luxury with spaciousness, accommodating up to 6 passengers comfortably. Ideal for families or small groups who desire extra space without compromising on comfort.",
    capacity: "6 passengers",
    luggage: "5 medium suitcases",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    features: [
      { icon: "thermometer", name: "Dual-Zone Climate Control" },
      { icon: "wifi", name: "Free WiFi" },
      { icon: "music", name: "Premium Audio" },
      { icon: "briefcase", name: "Extra Luggage Space" },
      { icon: "users", name: "Professional Driver" },
    ],
    models: ["Mercedes-Benz GLE", "BMW X5", "Cadillac Escalade"],
    price: "Starting from 350 SAR",
  },
  {
    id: "van",
    name: "Premium Van",
    description:
      "Our premium vans are perfect for medium-sized groups, offering ample space for up to 12 passengers. These vehicles ensure everyone travels together in comfort with plenty of room for luggage.",
    capacity: "12 passengers",
    luggage: "12 medium suitcases",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    features: [
      { icon: "thermometer", name: "Multi-Zone Climate Control" },
      { icon: "wifi", name: "Free WiFi" },
      { icon: "music", name: "Entertainment System" },
      { icon: "briefcase", name: "Large Luggage Space" },
      { icon: "users", name: "Professional Driver" },
    ],
    models: ["Mercedes-Benz Sprinter", "Toyota Hiace VIP", "Volkswagen Crafter"],
    price: "Starting from 600 SAR",
  },
  {
    id: "bus",
    name: "Luxury Bus",
    description:
      "Our luxury buses are designed for large groups, accommodating up to 30 passengers with maximum comfort. Perfect for group pilgrimages, these vehicles feature premium amenities for a pleasant journey.",
    capacity: "30 passengers",
    luggage: "30 medium suitcases",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    features: [
      { icon: "thermometer", name: "Climate Control" },
      { icon: "wifi", name: "Free WiFi" },
      { icon: "music", name: "Entertainment System" },
      { icon: "briefcase", name: "Ample Luggage Space" },
      { icon: "users", name: "Professional Driver" },
    ],
    models: ["Mercedes-Benz Tourismo", "Volvo 9700", "Scania Touring"],
    price: "Starting from 1200 SAR",
  },
]

export default function VehiclesPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link href="/" className="mb-6 inline-flex items-center text-emerald-800 hover:text-emerald-600">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Our Premium Fleet</h1>
        <div className="mt-2 h-1 w-20 bg-amber-400"></div>
        <p className="mt-4 max-w-3xl text-gray-600">
          Choose from our range of luxury vehicles, each designed to provide maximum comfort during your journey. All
          our vehicles are regularly maintained, fully insured, and operated by professional drivers.
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-8 grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="all">All Vehicles</TabsTrigger>
          <TabsTrigger value="sedan">Sedans</TabsTrigger>
          <TabsTrigger value="suv">SUVs</TabsTrigger>
          <TabsTrigger value="van">Vans</TabsTrigger>
          <TabsTrigger value="bus">Buses</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-16">
          {vehiclesData.map((vehicle, index) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} index={index} />
          ))}
        </TabsContent>

        {vehiclesData.map((vehicle) => (
          <TabsContent key={vehicle.id} value={vehicle.id}>
            <VehicleCard vehicle={vehicle} index={0} />
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-16 rounded-lg bg-emerald-50 p-8">
        <div className="text-center">
          <h2 className="mb-4 font-serif text-2xl font-bold text-emerald-800">Ready to Book Your Vehicle?</h2>
          <p className="mb-6 text-gray-600">
            Select the perfect vehicle for your journey and enjoy a comfortable, reliable transportation experience.
          </p>
          <Link href="/booking">
            <Button size="lg" className="bg-emerald-800 hover:bg-emerald-700">
              Book Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

