import type { Metadata } from "next"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import AnimatedSection from "@/components/animated-section"

export const metadata: Metadata = {
  title: "About Us | Umrah Transport",
  description: "Learn about our premium transportation services for Umrah pilgrims in Saudi Arabia.",
}

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link href="/" className="mb-6 inline-flex items-center text-emerald-800 hover:text-emerald-600">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">About Umrah Transport</h1>
        <div className="mt-2 h-1 w-20 bg-amber-400"></div>
      </div>

      <div className="grid gap-12 md:grid-cols-2">
        <AnimatedSection animation="slide-right">
          <div className="relative h-[400px] overflow-hidden rounded-lg shadow-lg md:h-full">
            <Image
              src="/placeholder.svg?height=800&width=600"
              alt="Our transportation fleet"
              fill
              className="object-cover"
            />
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slide-left">
          <div className="flex flex-col justify-center space-y-6">
            <h2 className="font-serif text-2xl font-bold text-emerald-800">Our Story</h2>
            <p className="text-gray-600">
              Founded in 2010, Umrah Transport was established with a clear mission: to provide pilgrims with
              transportation services that combine luxury, reliability, and cultural respect. What began as a small
              fleet of vehicles has grown into one of Saudi Arabia's premier transportation providers for Umrah
              pilgrims.
            </p>
            <p className="text-gray-600">
              Our founder, Abdullah Al-Faisal, recognized the need for transportation services that understood the
              unique requirements of pilgrims. Having performed Umrah numerous times himself, he was familiar with the
              challenges pilgrims faced when traveling between holy sites and accommodations.
            </p>
            <p className="text-gray-600">
              Today, Umrah Transport operates a diverse fleet of luxury vehicles and employs a team of professional
              drivers who are not only skilled behind the wheel but also knowledgeable about the pilgrimage experience.
            </p>
          </div>
        </AnimatedSection>
      </div>

      <div className="my-16">
        <AnimatedSection animation="fade-in">
          <div className="text-center">
            <h2 className="font-serif text-3xl font-bold text-emerald-800">Our Mission & Values</h2>
            <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-3">
            <div className="rounded-lg bg-emerald-50 p-6 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-8 w-8 text-emerald-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                  />
                </svg>
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold text-emerald-800">Safety First</h3>
              <p className="text-gray-600">
                We prioritize the safety of our passengers above all else, with well-maintained vehicles and
                professional drivers who adhere to the highest safety standards.
              </p>
            </div>

            <div className="rounded-lg bg-emerald-50 p-6 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-8 w-8 text-emerald-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold text-emerald-800">Reliability</h3>
              <p className="text-gray-600">
                We understand the importance of punctuality and dependability, especially during the sacred journey of
                Umrah. Our services are designed to be consistently reliable.
              </p>
            </div>

            <div className="rounded-lg bg-emerald-50 p-6 text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-8 w-8 text-emerald-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                  />
                </svg>
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold text-emerald-800">Cultural Respect</h3>
              <p className="text-gray-600">
                We honor the cultural and religious significance of the Umrah pilgrimage, ensuring our services are
                delivered with the utmost respect and understanding.
              </p>
            </div>
          </div>
        </AnimatedSection>
      </div>

      <div className="my-16">
        <AnimatedSection animation="fade-in">
          <div className="text-center">
            <h2 className="font-serif text-3xl font-bold text-emerald-800">Our Team</h2>
            <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
            <p className="mx-auto mt-4 max-w-2xl text-gray-600">
              Our dedicated team of professionals is committed to providing exceptional service to every pilgrim we
              serve.
            </p>
          </div>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                name: "Abdullah Al-Faisal",
                role: "Founder & CEO",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Mohammed Rahman",
                role: "Operations Manager",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Fatima Al-Zahrani",
                role: "Customer Relations",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Khalid Al-Otaibi",
                role: "Fleet Manager",
                image: "/placeholder.svg?height=300&width=300",
              },
            ].map((member, index) => (
              <div key={index} className="text-center">
                <div className="mx-auto mb-4 h-40 w-40 overflow-hidden rounded-full">
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    width={160}
                    height={160}
                    className="h-full w-full object-cover"
                  />
                </div>
                <h3 className="font-serif text-xl font-semibold text-emerald-800">{member.name}</h3>
                <p className="text-gray-600">{member.role}</p>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </div>

      <div className="my-16">
        <AnimatedSection animation="fade-in">
          <div className="rounded-lg bg-emerald-50 p-8 md:p-12">
            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <h2 className="font-serif text-3xl font-bold text-emerald-800">Why Choose Us?</h2>
                <div className="mt-2 h-1 w-20 bg-amber-400"></div>
                <p className="mt-4 text-gray-600">
                  With years of experience serving pilgrims, we understand the unique needs and challenges of Umrah
                  transportation. Here's why thousands of pilgrims choose Umrah Transport every year:
                </p>

                <ul className="mt-6 space-y-3">
                  <li className="flex items-start">
                    <div className="mr-2 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3 text-amber-600"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-600">Experienced drivers familiar with pilgrimage routes</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3 text-amber-600"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-600">Modern, well-maintained luxury vehicles</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3 text-amber-600"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-600">24/7 customer support in multiple languages</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3 text-amber-600"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-600">Customizable transportation packages</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3 text-amber-600"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-600">Competitive pricing with no hidden fees</span>
                  </li>
                </ul>
              </div>

              <div className="flex items-center justify-center">
                <div className="rounded-lg bg-white p-6 shadow-md">
                  <h3 className="mb-4 font-serif text-xl font-semibold text-emerald-800">
                    Ready to Experience Our Service?
                  </h3>
                  <p className="mb-6 text-gray-600">
                    Book your transportation today and enjoy a comfortable, reliable journey during your Umrah
                    pilgrimage.
                  </p>
                  <div className="flex flex-col space-y-3 sm:flex-row sm:space-x-3 sm:space-y-0">
                    <Link href="/booking">
                      <Button className="w-full bg-emerald-800 hover:bg-emerald-700 sm:w-auto">Book Now</Button>
                    </Link>
                    <Link href="/contact">
                      <Button
                        variant="outline"
                        className="w-full border-emerald-800 text-emerald-800 hover:bg-emerald-50 sm:w-auto"
                      >
                        Contact Us
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </div>
  )
}

