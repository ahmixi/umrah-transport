import type { Metadata } from "next"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { Suspense } from "react"
import BookingForm from "@/components/booking-form"

export const metadata: Metadata = {
  title: "Book Your Transportation | Umrah Transport",
  description: "Book your premium transportation service for Umrah pilgrims in Saudi Arabia.",
}

export default function BookingPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link href="/" className="mb-6 inline-flex items-center text-emerald-800 hover:text-emerald-600">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Book Your Transportation</h1>
        <div className="mt-2 h-1 w-20 bg-amber-400"></div>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="rounded-lg bg-white p-6 shadow-md">
            {/* Wrap BookingForm in Suspense boundary */}
            <Suspense fallback={<div className="p-4 text-center">Loading booking form...</div>}>
              <BookingForm />
            </Suspense>
          </div>
        </div>

        <div>
          <div className="rounded-lg bg-emerald-50 p-6 shadow-md">
            <h2 className="mb-4 font-serif text-xl font-bold text-emerald-800">Booking Information</h2>

            <div className="mb-6 space-y-4">
              <div>
                <h3 className="font-medium text-emerald-800">Need Assistance?</h3>
                <p className="text-sm text-gray-600">
                  Our customer service team is available 24/7 to help you with your booking.
                </p>
                <p className="mt-2 text-sm font-medium text-emerald-800">Call: +966 12 345 6789</p>
              </div>

              <div>
                <h3 className="font-medium text-emerald-800">Booking Policy</h3>
                <ul className="mt-2 space-y-1 text-sm text-gray-600">
                  <li>• 30% deposit required to confirm booking</li>
                  <li>• Free cancellation up to 7 days before</li>
                  <li>• All prices include taxes and fees</li>
                </ul>
              </div>
            </div>

            <div className="rounded-md bg-amber-50 p-4">
              <h3 className="font-medium text-amber-800">Special Offer</h3>
              <p className="mt-1 text-sm text-amber-700">Book now and get a 10% discount on your return journey!</p>
              <p className="mt-2 text-xs text-amber-600">*Offer valid for bookings made before December 31st.</p>
            </div>
          </div>

          <div className="mt-6 rounded-lg bg-white p-6 shadow-md">
            <h2 className="mb-4 font-serif text-xl font-bold text-emerald-800">Why Choose Us</h2>
            <ul className="space-y-3">
              <li className="flex items-start">
                <div className="mr-2 h-5 w-5 rounded-full bg-emerald-100 p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="h-3 w-3 text-emerald-600"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span className="text-sm text-gray-600">Professional, experienced drivers</span>
              </li>
              <li className="flex items-start">
                <div className="mr-2 h-5 w-5 rounded-full bg-emerald-100 p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="h-3 w-3 text-emerald-600"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span className="text-sm text-gray-600">Modern, comfortable vehicles</span>
              </li>
              <li className="flex items-start">
                <div className="mr-2 h-5 w-5 rounded-full bg-emerald-100 p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="h-3 w-3 text-emerald-600"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span className="text-sm text-gray-600">24/7 customer support</span>
              </li>
              <li className="flex items-start">
                <div className="mr-2 h-5 w-5 rounded-full bg-emerald-100 p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="h-3 w-3 text-emerald-600"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span className="text-sm text-gray-600">Secure online payment</span>
              </li>
              <li className="flex items-start">
                <div className="mr-2 h-5 w-5 rounded-full bg-emerald-100 p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="h-3 w-3 text-emerald-600"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span className="text-sm text-gray-600">Flexible cancellation policy</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

