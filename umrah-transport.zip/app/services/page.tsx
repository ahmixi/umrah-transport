import type { Metadata } from "next"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, MapPin, Calendar, Users, Clock, Star, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import AnimatedSection from "@/components/animated-section"

export const metadata: Metadata = {
  title: "Our Services | Umrah Transport",
  description: "Explore our premium transportation services for Umrah pilgrims in Saudi Arabia.",
}

export default function ServicesPage() {
  const services = [
    {
      id: "airport-transfers",
      title: "Airport Transfers",
      icon: <MapPin className="h-12 w-12 text-amber-500" />,
      description:
        "Our airport transfer service ensures a smooth start and end to your journey. We monitor flight arrivals in real-time to adjust for any delays, and our drivers will be waiting for you at the arrival hall with a personalized greeting sign. All our vehicles have ample luggage space to accommodate your belongings.",
      features: [
        "Meet & greet service at the arrival hall",
        "Flight monitoring for delays",
        "Assistance with luggage",
        "Direct transfer to your accommodation",
        "Available from all major airports in Saudi Arabia",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
    {
      id: "holy-sites",
      title: "Holy Site Transportation",
      icon: <Calendar className="h-12 w-12 text-amber-500" />,
      description:
        "Visit the sacred sites with comfort and ease. Our drivers are knowledgeable about all pilgrimage routes and can provide guidance on the best times to visit. We ensure timely arrivals and departures, allowing you to focus entirely on your spiritual journey without worrying about transportation logistics.",
      features: [
        "Transportation to all major holy sites",
        "Knowledgeable drivers familiar with pilgrimage protocols",
        "Flexible scheduling to accommodate prayer times",
        "Air-conditioned vehicles for comfort in all weather",
        "Option for dedicated driver throughout your stay",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
    {
      id: "group-transport",
      title: "Group Transportation",
      icon: <Users className="h-12 w-12 text-amber-500" />,
      description:
        "Keep your group together with our specialized group transportation services. Whether you're traveling with family or as part of a larger pilgrimage group, we have vehicles to accommodate parties of all sizes. Our group services include coordination assistance to ensure everyone stays together throughout the journey.",
      features: [
        "Vehicles for groups of all sizes (5 to 50+ passengers)",
        "Group coordination assistance",
        "Dedicated group liaison",
        "Customized itineraries for groups",
        "Special rates for large groups",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
    {
      id: "availability",
      title: "24/7 Availability",
      icon: <Clock className="h-12 w-12 text-amber-500" />,
      description:
        "Our services are available around the clock to accommodate your schedule and needs. Whether you need early morning airport transfers or late-night transportation between sites, our team is ready to serve you at any hour. Our 24/7 customer support ensures assistance is always just a phone call away.",
      features: [
        "Round-the-clock service availability",
        "24/7 customer support hotline",
        "Emergency transportation services",
        "Flexible scheduling for early or late journeys",
        "No additional charges for night services",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
    {
      id: "custom-packages",
      title: "Customized Packages",
      icon: <Star className="h-12 w-12 text-amber-500" />,
      description:
        "We understand that every pilgrim's journey is unique. Our customized packages allow you to tailor our transportation services to your specific needs and preferences. From vehicle selection to scheduling and special requests, we work with you to create the perfect transportation solution for your pilgrimage.",
      features: [
        "Personalized itinerary planning",
        "Combination of different services",
        "Special accommodations for elderly or disabled travelers",
        "Custom vehicle branding for large groups",
        "Add-on services like guided tours or translation",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
    {
      id: "drivers",
      title: "Multilingual Drivers",
      icon: <Mail className="h-12 w-12 text-amber-500" />,
      description:
        "Communication is key to a smooth journey. Our professional drivers are fluent in multiple languages including Arabic, English, Urdu, French, and more. This ensures clear communication throughout your transportation experience, allowing you to express your needs and receive information without language barriers.",
      features: [
        "Drivers fluent in multiple languages",
        "Cultural sensitivity and awareness",
        "Professional training and certification",
        "Knowledge of local customs and traditions",
        "Ability to provide basic information about sites and locations",
      ],
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link href="/" className="mb-6 inline-flex items-center text-emerald-800 hover:text-emerald-600">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Our Services</h1>
        <div className="mt-2 h-1 w-20 bg-amber-400"></div>
        <p className="mt-4 max-w-3xl text-gray-600">
          We offer comprehensive transportation solutions tailored to the needs of Umrah pilgrims in Saudi Arabia. Our
          services are designed to provide comfort, reliability, and peace of mind throughout your journey.
        </p>
      </div>

      <div className="space-y-16">
        {services.map((service, index) => (
          <div key={service.id} id={service.id} className="scroll-mt-20">
            <AnimatedSection animation={index % 2 === 0 ? "slide-right" : "slide-left"}>
              <div className={`grid gap-8 md:grid-cols-2 ${index % 2 === 1 ? "md:grid-flow-dense" : ""}`}>
                <div className={`${index % 2 === 1 ? "md:col-start-2" : ""}`}>
                  <div className="mb-4 flex items-center">
                    {service.icon}
                    <h2 className="ml-4 font-serif text-2xl font-bold text-emerald-800 md:text-3xl">{service.title}</h2>
                  </div>
                  <p className="mb-6 text-gray-600">{service.description}</p>

                  <h3 className="mb-3 font-serif text-lg font-semibold text-emerald-700">Key Features:</h3>
                  <ul className="mb-6 space-y-2">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <div className="mr-2 mt-1 h-4 w-4 rounded-full bg-emerald-100 p-0.5">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                            className="h-3 w-3 text-emerald-600"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </div>
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link href="/booking">
                    <Button className="bg-emerald-800 hover:bg-emerald-700">Book This Service</Button>
                  </Link>
                </div>

                <div className={`${index % 2 === 1 ? "md:col-start-1" : ""}`}>
                  <div className="overflow-hidden rounded-lg shadow-lg">
                    <Image
                      src={service.image || "/placeholder.svg"}
                      alt={service.title}
                      width={600}
                      height={400}
                      className="h-full w-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </AnimatedSection>

            {index < services.length - 1 && <div className="my-16 h-px w-full bg-gray-200"></div>}
          </div>
        ))}
      </div>

      <div className="mt-16 rounded-lg bg-emerald-50 p-8">
        <div className="text-center">
          <h2 className="mb-4 font-serif text-2xl font-bold text-emerald-800">Need a Custom Service?</h2>
          <p className="mb-6 text-gray-600">
            Don't see exactly what you need? Contact us to discuss your specific requirements and we'll create a custom
            transportation solution for you.
          </p>
          <div className="flex flex-col justify-center space-x-0 space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
            <Link href="/contact">
              <Button className="bg-emerald-800 hover:bg-emerald-700">Contact Us</Button>
            </Link>
            <Link href="/booking">
              <Button variant="outline" className="border-emerald-800 text-emerald-800 hover:bg-emerald-100">
                Book a Service
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

