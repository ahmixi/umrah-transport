import Link from "next/link"
import { ChevronRight, Phone, Mail, MapPin, Star, Calendar, Users, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import VehicleCarousel from "@/components/vehicle-carousel"
import TestimonialSlider from "@/components/testimonial-slider"
import AnimatedSection from "@/components/animated-section"
import BookingSteps from "@/components/booking-steps"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header/Navbar */}
      <header className="sticky top-0 z-50 border-b bg-white/95 backdrop-blur-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link href="/" className="flex items-center">
            <div className="mr-2 rounded-full bg-emerald-100 p-1">
              <MapPin className="h-6 w-6 text-emerald-800" />
            </div>
            <span className="font-serif text-xl font-bold text-emerald-800">Umrah Transport</span>
          </Link>

          <nav className="hidden space-x-6 md:flex">
            <Link href="/" className="text-emerald-800 hover:text-emerald-600">
              Home
            </Link>
            <Link href="/services" className="text-emerald-800 hover:text-emerald-600">
              Services
            </Link>
            <Link href="/vehicles" className="text-emerald-800 hover:text-emerald-600">
              Our Fleet
            </Link>
            <Link href="/booking" className="text-emerald-800 hover:text-emerald-600">
              Book Now
            </Link>
            <Link href="/contact" className="text-emerald-800 hover:text-emerald-600">
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="/booking" className="hidden md:block">
              <Button className="bg-amber-500 text-emerald-900 hover:bg-amber-400">Book Now</Button>
            </Link>
            <Button variant="outline" className="md:hidden">
              <span className="sr-only">Open menu</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[80vh] overflow-hidden bg-gradient-to-r from-emerald-900 to-emerald-800">
          <div className="absolute inset-0 bg-[url('/hero-pattern.svg')] opacity-10"></div>
          <div className="container relative z-10 mx-auto flex h-full flex-col items-center justify-center px-4 text-center">
            <AnimatedSection animation="fade-in">
              <h1 className="mb-6 font-serif text-4xl font-bold text-amber-400 md:text-6xl lg:text-7xl">
                Luxury Transportation for Umrah Pilgrims
              </h1>
              <p className="mb-8 max-w-3xl text-lg text-white md:text-xl">
                Experience comfort, reliability, and cultural respect with our premium transportation services designed
                specifically for pilgrims in Saudi Arabia.
              </p>
              <div className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
                <Link href="/booking">
                  <Button size="lg" className="bg-amber-500 text-emerald-900 hover:bg-amber-400">
                    Book Your Journey
                  </Button>
                </Link>
                <Link href="/services">
                  <Button size="lg" variant="outline" className="border-amber-400 text-amber-400 hover:bg-amber-400/10">
                    Explore Our Services
                  </Button>
                </Link>
              </div>
            </AnimatedSection>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-emerald-950 to-transparent"></div>
        </section>

        {/* Booking Steps Section */}
        <section className="bg-white py-16">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fade-in">
              <div className="mb-12 text-center">
                <h2 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Book in 3 Simple Steps</h2>
                <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
                <p className="mx-auto mt-4 max-w-2xl text-gray-600">
                  Our streamlined booking process makes it easy to arrange your transportation
                </p>
              </div>
            </AnimatedSection>

            <BookingSteps />

            <div className="mt-10 text-center">
              <Link href="/booking">
                <Button size="lg" className="bg-emerald-800 hover:bg-emerald-700">
                  Start Booking Now
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Our Fleet Section */}
        <section className="bg-emerald-50 py-20">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fade-in">
              <div className="mb-12 text-center">
                <h2 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Our Premium Fleet</h2>
                <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
                <p className="mx-auto mt-4 max-w-2xl text-gray-600">
                  Choose from our range of luxury vehicles, each designed to provide maximum comfort during your journey
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-in">
              <VehicleCarousel />
            </AnimatedSection>

            <div className="mt-10 text-center">
              <Link href="/vehicles">
                <Button className="bg-emerald-800 hover:bg-emerald-700">View All Vehicles</Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="bg-white py-20">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fade-in">
              <div className="mb-12 text-center">
                <h2 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Our Services</h2>
                <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
                <p className="mx-auto mt-4 max-w-2xl text-gray-600">
                  We offer comprehensive transportation solutions tailored to the needs of Umrah pilgrims
                </p>
              </div>
            </AnimatedSection>

            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Airport Transfers",
                  icon: <MapPin className="h-10 w-10 text-amber-500" />,
                  description: "Seamless pickup and drop-off services at all major airports in Saudi Arabia.",
                  link: "/services#airport-transfers",
                },
                {
                  title: "Holy Site Transportation",
                  icon: <Calendar className="h-10 w-10 text-amber-500" />,
                  description:
                    "Reliable transportation between holy sites with knowledgeable drivers familiar with pilgrimage routes.",
                  link: "/services#holy-sites",
                },
                {
                  title: "Group Transportation",
                  icon: <Users className="h-10 w-10 text-amber-500" />,
                  description:
                    "Comfortable vehicles for groups of all sizes, ensuring your group stays together throughout the journey.",
                  link: "/services#group-transport",
                },
                {
                  title: "24/7 Availability",
                  icon: <Clock className="h-10 w-10 text-amber-500" />,
                  description: "Our services are available around the clock to accommodate your schedule and needs.",
                  link: "/services#availability",
                },
                {
                  title: "Customized Packages",
                  icon: <Star className="h-10 w-10 text-amber-500" />,
                  description:
                    "Tailored transportation packages designed to meet your specific requirements and preferences.",
                  link: "/services#custom-packages",
                },
                {
                  title: "Multilingual Drivers",
                  icon: <Mail className="h-10 w-10 text-amber-500" />,
                  description: "Professional drivers fluent in multiple languages to ensure clear communication.",
                  link: "/services#drivers",
                },
              ].map((service, index) => (
                <AnimatedSection key={index} animation="scale-in" delay={index * 0.1}>
                  <Link href={service.link}>
                    <Card className="group h-full overflow-hidden transition-all duration-300 hover:shadow-lg hover:ring-2 hover:ring-emerald-100">
                      <CardContent className="flex h-full flex-col p-6">
                        <div className="mb-4 rounded-full bg-emerald-50 p-3 transition-all duration-300 group-hover:bg-emerald-100">
                          {service.icon}
                        </div>
                        <h3 className="mb-2 font-serif text-xl font-semibold text-emerald-800">{service.title}</h3>
                        <p className="text-gray-600">{service.description}</p>
                        <div className="mt-4 flex items-center text-amber-500">
                          <span className="text-sm font-medium">Learn more</span>
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </AnimatedSection>
              ))}
            </div>

            <div className="mt-10 text-center">
              <Link href="/services">
                <Button className="bg-emerald-800 hover:bg-emerald-700">View All Services</Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="bg-emerald-50 py-20">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fade-in">
              <div className="mb-12 text-center">
                <h2 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">What Our Clients Say</h2>
                <div className="mx-auto mt-2 h-1 w-20 bg-amber-400"></div>
                <p className="mx-auto mt-4 max-w-2xl text-gray-600">
                  Read testimonials from pilgrims who have experienced our premium transportation services
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-in">
              <TestimonialSlider />
            </AnimatedSection>
          </div>
        </section>

        {/* Call to Action */}
        <section className="bg-gradient-to-r from-emerald-900 to-emerald-800 py-16">
          <div className="container mx-auto px-4 text-center">
            <AnimatedSection animation="fade-in">
              <h2 className="mb-6 font-serif text-3xl font-bold text-amber-400 md:text-4xl">
                Ready to Experience Premium Transportation?
              </h2>
              <p className="mx-auto mb-8 max-w-2xl text-lg text-white">
                Book your journey today and enjoy a comfortable, reliable, and culturally respectful transportation
                experience for your Umrah pilgrimage.
              </p>
              <Link href="/booking">
                <Button size="lg" className="bg-amber-500 text-emerald-900 hover:bg-amber-400">
                  Book Your Journey Now
                </Button>
              </Link>
            </AnimatedSection>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-emerald-950 py-12 text-emerald-100">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <h3 className="mb-4 font-serif text-xl font-bold text-amber-400">Umrah Transport</h3>
              <p className="mb-4">Providing premium transportation services for Umrah pilgrims in Saudi Arabia.</p>
              <div className="flex space-x-4">{/* Social media icons would go here */}</div>
            </div>
            <div>
              <h3 className="mb-4 font-serif text-xl font-bold text-amber-400">Quick Links</h3>
              <ul className="space-y-2">
                {[
                  { name: "Home", path: "/" },
                  { name: "About Us", path: "/about" },
                  { name: "Services", path: "/services" },
                  { name: "Our Fleet", path: "/vehicles" },
                  { name: "Book Now", path: "/booking" },
                  { name: "Contact Us", path: "/contact" },
                ].map((link) => (
                  <li key={link.name}>
                    <Link href={link.path} className="hover:text-amber-300">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="mb-4 font-serif text-xl font-bold text-amber-400">Contact Us</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <MapPin className="mr-2 h-5 w-5 text-amber-400" />
                  <span>123 King Fahd Road, Makkah, Saudi Arabia</span>
                </li>
                <li className="flex items-start">
                  <Phone className="mr-2 h-5 w-5 text-amber-400" />
                  <span>+966 12 345 6789</span>
                </li>
                <li className="flex items-start">
                  <Mail className="mr-2 h-5 w-5 text-amber-400" />
                  <span>info@umrahtransport.com</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 font-serif text-xl font-bold text-amber-400">Newsletter</h3>
              <p className="mb-4">Subscribe to receive updates and special offers.</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full rounded-l-md border-0 bg-emerald-800 px-4 py-2 text-white placeholder:text-emerald-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
                <Button className="rounded-l-none bg-amber-500 text-emerald-900 hover:bg-amber-400">Subscribe</Button>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t border-emerald-800 pt-8 text-center">
            <p className="mb-4">&copy; {new Date().getFullYear()} Umrah Transport. All rights reserved.</p>
            <Link href="/admin">
              <Button
                variant="outline"
                size="sm"
                className="border-emerald-800 bg-transparent text-emerald-400 hover:bg-emerald-900 hover:text-amber-400"
              >
                Admin Access
              </Button>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

