import type { Metadata } from "next"
import Link from "next/link"
import { ChevronLeft, Phone, Mail, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import AnimatedSection from "@/components/animated-section"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Contact Us | Umrah Transport",
  description: "Get in touch with our team for any inquiries about our transportation services for Umrah pilgrims.",
}

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Link href="/" className="mb-6 inline-flex items-center text-emerald-800 hover:text-emerald-600">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="font-serif text-3xl font-bold text-emerald-800 md:text-4xl">Contact Us</h1>
        <div className="mt-2 h-1 w-20 bg-amber-400"></div>
        <p className="mt-4 max-w-3xl text-gray-600">
          Have questions or need assistance? Our team is here to help you with any inquiries about our transportation
          services.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <AnimatedSection animation="slide-up">
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-6 font-serif text-2xl font-bold text-emerald-800">Send Us a Message</h2>
              <ContactForm />
            </div>
          </AnimatedSection>
        </div>

        <div>
          <AnimatedSection animation="slide-left">
            <div className="rounded-lg bg-emerald-50 p-6 shadow-md">
              <h2 className="mb-6 font-serif text-2xl font-bold text-emerald-800">Contact Information</h2>

              <div className="space-y-6">
                <div>
                  <div className="flex items-center">
                    <div className="rounded-full bg-emerald-100 p-2 text-emerald-600">
                      <Phone className="h-5 w-5" />
                    </div>
                    <h3 className="ml-3 font-medium text-emerald-800">Phone</h3>
                  </div>
                  <p className="mt-2 pl-10 text-gray-600">+966 12 345 6789</p>
                  <p className="pl-10 text-gray-600">+966 12 987 6543</p>
                </div>

                <div>
                  <div className="flex items-center">
                    <div className="rounded-full bg-emerald-100 p-2 text-emerald-600">
                      <Mail className="h-5 w-5" />
                    </div>
                    <h3 className="ml-3 font-medium text-emerald-800">Email</h3>
                  </div>
                  <p className="mt-2 pl-10 text-gray-600">info@umrahtransport.com</p>
                  <p className="pl-10 text-gray-600">bookings@umrahtransport.com</p>
                </div>

                <div>
                  <div className="flex items-center">
                    <div className="rounded-full bg-emerald-100 p-2 text-emerald-600">
                      <MapPin className="h-5 w-5" />
                    </div>
                    <h3 className="ml-3 font-medium text-emerald-800">Address</h3>
                  </div>
                  <p className="mt-2 pl-10 text-gray-600">
                    123 King Fahd Road
                    <br />
                    Makkah, Saudi Arabia
                  </p>
                </div>

                <div>
                  <div className="flex items-center">
                    <div className="rounded-full bg-emerald-100 p-2 text-emerald-600">
                      <Clock className="h-5 w-5" />
                    </div>
                    <h3 className="ml-3 font-medium text-emerald-800">Business Hours</h3>
                  </div>
                  <p className="mt-2 pl-10 text-gray-600">
                    24/7 Customer Support
                    <br />
                    Office Hours: 9:00 AM - 9:00 PM
                  </p>
                </div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="slide-left" delay={0.2}>
            <div className="mt-6 rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-4 font-serif text-xl font-bold text-emerald-800">Need Immediate Assistance?</h2>
              <p className="mb-4 text-gray-600">
                For urgent inquiries or immediate booking assistance, please call our 24/7 customer support line.
              </p>
              <a href="tel:+966123456789">
                <Button className="w-full bg-amber-500 text-emerald-900 hover:bg-amber-400">
                  <Phone className="mr-2 h-4 w-4" /> Call Now
                </Button>
              </a>
            </div>
          </AnimatedSection>
        </div>
      </div>

      <AnimatedSection animation="fade-in" delay={0.3}>
        <div className="mt-12 rounded-lg overflow-hidden h-96 shadow-lg">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14959.071349090901!2d39.82289!3d21.42251!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c204b74c28d467%3A0xb2f543a618225767!2sMakkah%20Saudi%20Arabia!5e0!3m2!1sen!2sus!4v1616661863576!5m2!1sen!2sus"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            title="Umrah Transport Location"
          ></iframe>
        </div>
      </AnimatedSection>
    </div>
  )
}

