"use client"

import Image from "next/image"
import {
  Filter,
  Download,
  Plus,
  Search,
  MapPin,
  AlertCircle,
  CheckCircle,
  Settings,
  MoreHorizontal,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { getVehicles, updateVehicleStatus } from "@/lib/actions"
import Link from "next/link"
import { useEffect, useState } from "react"

export default function FleetPageClient() {
  const [vehicles, setVehicles] = useState([])
  useEffect(() => {
    const fetchVehicles = async () => {
      const data = await getVehicles()
      setVehicles(data)
    }
    fetchVehicles()
  }, [])

  const availableCount = vehicles.filter((v) => v.status === "available").length
  const inUseCount = vehicles.filter((v) => v.status === "in-use").length
  const maintenanceCount = vehicles.filter((v) => v.status === "maintenance").length
  const inactiveCount = vehicles.filter((v) => v.status === "inactive").length

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "available":
        return (
          <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">Available</Badge>
        )
      case "in-use":
        return (
          <Badge variant="outline" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
            In Use
          </Badge>
        )
      case "maintenance":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-400">
            Maintenance
          </Badge>
        )
      case "inactive":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400">
            Inactive
          </Badge>
        )
      default:
        return (
          <Badge variant="outline">
            <span>{status}</span>
          </Badge>
        )
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between space-y-4 md:flex-row md:items-center md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Fleet Management</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Manage and track your vehicle fleet</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2" onClick={() => window.print()}>
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Link href="/admin/fleet/new">
            <Button className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
              <Plus className="h-4 w-4" />
              <span>Add Vehicle</span>
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Vehicles</CardTitle>
            <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
              {vehicles.length}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{vehicles.length}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Vehicles in the fleet</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Available</CardTitle>
            <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
              {availableCount}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{availableCount}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Ready for booking</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">In Use</CardTitle>
            <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">{inUseCount}</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inUseCount}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Currently on trips</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Maintenance</CardTitle>
            <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-400">{maintenanceCount}</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{maintenanceCount}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Under maintenance</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Vehicle Fleet</CardTitle>
            <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
              <div className="relative w-full sm:w-[300px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input placeholder="Search vehicles..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="in-use">In Use</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Vehicle Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="sedan">Luxury Sedan</SelectItem>
                  <SelectItem value="suv">Executive SUV</SelectItem>
                  <SelectItem value="van">Premium Van</SelectItem>
                  <SelectItem value="bus">Luxury Bus</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="grid" className="w-full">
            <div className="mb-4 flex justify-end">
              <TabsList>
                <TabsTrigger value="grid">Grid View</TabsTrigger>
                <TabsTrigger value="list">List View</TabsTrigger>
                <TabsTrigger value="map">Map View</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="grid" className="mt-0">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {vehicles.map((vehicle) => (
                  <Card key={vehicle.id} className="overflow-hidden border-none shadow-md">
                    <div className="relative h-40 w-full">
                      <Image
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg"
                        alt={vehicle.name}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute right-2 top-2">{getStatusBadge(vehicle.status)}</div>
                    </div>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{vehicle.name}</CardTitle>
                          <CardDescription>{vehicle.type}</CardDescription>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Link href={`/admin/fleet/${vehicle.id}`} className="flex w-full items-center">
                                View Details
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Link href={`/admin/fleet/${vehicle.id}/edit`} className="flex w-full items-center">
                                Edit Vehicle
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="cursor-pointer"
                              onClick={async () => {
                                await updateVehicleStatus(vehicle.id, "maintenance")
                              }}
                            >
                              Schedule Maintenance
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="cursor-pointer text-red-600 dark:text-red-400"
                              onClick={async () => {
                                await updateVehicleStatus(vehicle.id, "inactive")
                              }}
                            >
                              Mark as Inactive
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500 dark:text-gray-400">License Plate:</span>
                        <span className="font-medium">{vehicle.licensePlate}</span>
                      </div>

                      {vehicle.driver && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500 dark:text-gray-400">Driver:</span>
                          <span className="font-medium">{vehicle.driver}</span>
                        </div>
                      )}

                      {vehicle.location && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500 dark:text-gray-400">Location:</span>
                          <span className="flex items-center font-medium">
                            <MapPin className="mr-1 h-3 w-3 text-emerald-600" />
                            {vehicle.location}
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500 dark:text-gray-400">Next Service:</span>
                        <span className="flex items-center font-medium">
                          {new Date(vehicle.nextService) < new Date() ? (
                            <AlertCircle className="mr-1 h-3 w-3 text-red-600" />
                          ) : (
                            <CheckCircle className="mr-1 h-3 w-3 text-emerald-600" />
                          )}
                          {vehicle.nextService}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500 dark:text-gray-400">Fuel Level</span>
                          <span className="font-medium">{vehicle.fuelLevel}%</span>
                        </div>
                        <Progress
                          value={vehicle.fuelLevel}
                          className="h-1.5"
                          indicatorColor={
                            vehicle.fuelLevel > 70
                              ? "bg-emerald-600"
                              : vehicle.fuelLevel > 30
                                ? "bg-amber-500"
                                : "bg-red-500"
                          }
                        />
                      </div>

                      <div className="flex justify-between pt-2">
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          <span>Track</span>
                        </Button>
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Settings className="h-3 w-3" />
                          <span>Manage</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="list" className="mt-0">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b text-left text-xs font-medium text-gray-500 dark:border-gray-800 dark:text-gray-400">
                      <th className="px-4 py-3">Vehicle ID</th>
                      <th className="px-4 py-3">Name</th>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3">License Plate</th>
                      <th className="px-4 py-3">Driver</th>
                      <th className="px-4 py-3">Location</th>
                      <th className="px-4 py-3">Next Service</th>
                      <th className="px-4 py-3">Fuel Level</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y dark:divide-gray-800">
                    {vehicles.map((vehicle) => (
                      <tr
                        key={vehicle.id}
                        className="text-sm text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800/50"
                      >
                        <td className="whitespace-nowrap px-4 py-3 font-medium">{vehicle.id}</td>
                        <td className="whitespace-nowrap px-4 py-3">{vehicle.name}</td>
                        <td className="whitespace-nowrap px-4 py-3">{vehicle.type}</td>
                        <td className="whitespace-nowrap px-4 py-3">{vehicle.licensePlate}</td>
                        <td className="whitespace-nowrap px-4 py-3">{vehicle.driver || "-"}</td>
                        <td className="whitespace-nowrap px-4 py-3">
                          {vehicle.location ? (
                            <span className="flex items-center">
                              <MapPin className="mr-1 h-3 w-3 text-emerald-600" />
                              {vehicle.location}
                            </span>
                          ) : (
                            "-"
                          )}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <span className="flex items-center">
                            {new Date(vehicle.nextService) < new Date() ? (
                              <AlertCircle className="mr-1 h-3 w-3 text-red-600" />
                            ) : (
                              <CheckCircle className="mr-1 h-3 w-3 text-emerald-600" />
                            )}
                            {vehicle.nextService}
                          </span>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <div className="flex w-32 items-center gap-2">
                            <Progress
                              value={vehicle.fuelLevel}
                              className="h-1.5"
                              indicatorColor={
                                vehicle.fuelLevel > 70
                                  ? "bg-emerald-600"
                                  : vehicle.fuelLevel > 30
                                    ? "bg-amber-500"
                                    : "bg-red-500"
                              }
                            />
                            <span className="text-xs font-medium">{vehicle.fuelLevel}%</span>
                          </div>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">{getStatusBadge(vehicle.status)}</td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Link href={`/admin/fleet/${vehicle.id}`} className="flex w-full items-center">
                                  View Details
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Link href={`/admin/fleet/${vehicle.id}/edit`} className="flex w-full items-center">
                                  Edit Vehicle
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={async () => {
                                  await updateVehicleStatus(vehicle.id, "maintenance")
                                }}
                              >
                                Schedule Maintenance
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="cursor-pointer text-red-600 dark:text-red-400"
                                onClick={async () => {
                                  await updateVehicleStatus(vehicle.id, "inactive")
                                }}
                              >
                                Mark as Inactive
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="map" className="mt-0">
              <div className="rounded-lg border border-gray-200 dark:border-gray-800">
                <div className="relative h-[500px] w-full overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="mx-auto h-12 w-12 text-emerald-600 opacity-20" />
                      <p className="mt-2 text-gray-500 dark:text-gray-400">
                        Map view showing vehicle locations would appear here
                      </p>
                      <Button className="mt-4 bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                        Load Map View
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

