import type { Metadata } from "next"
import FleetPageClient from "./FleetPageClient"

export const metadata: Metadata = {
  title: "Fleet Management | Umrah Transport Admin",
  description: "Manage your vehicle fleet for Umrah Transport services",
}

export default async function FleetPage() {
  return <FleetPageClient />
}

