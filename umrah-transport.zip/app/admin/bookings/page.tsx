import type { Metadata } from "next"
import BookingsClientPage from "./BookingsClientPage"

export const metadata: Metadata = {
  title: "Bookings | Umrah Transport Admin",
  description: "Manage all bookings for Umrah Transport services",
}

export default async function BookingsPage() {
  return <BookingsClientPage />
}

