import type { Metadata } from "next"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import AdminBookingForm from "@/components/admin/admin-booking-form"

export const metadata: Metadata = {
  title: "New Booking | Umrah Transport Admin",
  description: "Create a new booking for Umrah Transport services",
}

export default function NewBookingPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link
            href="/admin/bookings"
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">New Booking</h2>
        </div>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader>
          <CardTitle>Create New Booking</CardTitle>
        </CardHeader>
        <CardContent>
          <AdminBookingForm />
        </CardContent>
      </Card>
    </div>
  )
}

