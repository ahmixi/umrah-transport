import type { Metadata } from "next"
import {
  Filter,
  Download,
  Plus,
  Search,
  MoreHorizontal,
  Mail,
  Phone,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Customer Management | Umrah Transport Admin",
  description: "Manage customer information for Umrah Transport services",
}

export default function CustomersPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between space-y-4 md:flex-row md:items-center md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Customer Management</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Manage and track customer information</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
            <Plus className="h-4 w-4" />
            <span>Add Customer</span>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">2,548</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,548</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Registered customers</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
            <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">1,842</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,842</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Made a booking in the last 3 months</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">New Customers</CardTitle>
            <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">156</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Joined in the last 30 days</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">VIP Customers</CardTitle>
            <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-400">78</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Premium tier customers</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Customer Database</CardTitle>
            <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
              <div className="relative w-full sm:w-[300px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input placeholder="Search customers..." className="pl-10" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Customer Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Customers</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="vip">VIP</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4 grid w-full grid-cols-4">
              <TabsTrigger value="all">All Customers</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="inactive">Inactive</TabsTrigger>
              <TabsTrigger value="vip">VIP</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b text-left text-xs font-medium text-gray-500 dark:border-gray-800 dark:text-gray-400">
                      <th className="px-4 py-3">Customer ID</th>
                      <th className="px-4 py-3">Name</th>
                      <th className="px-4 py-3">Contact</th>
                      <th className="px-4 py-3">Location</th>
                      <th className="px-4 py-3">Total Bookings</th>
                      <th className="px-4 py-3">Last Booking</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y dark:divide-gray-800">
                    {Array.from({ length: 10 }).map((_, index) => (
                      <tr
                        key={index}
                        className="text-sm text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800/50"
                      >
                        <td className="whitespace-nowrap px-4 py-3 font-medium">C-100{index + 1}</td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                              <AvatarFallback>{index % 2 === 0 ? "AM" : index % 3 === 0 ? "FR" : "MY"}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">
                                {index % 2 === 0
                                  ? "Ahmed Al-Farsi"
                                  : index % 3 === 0
                                    ? "Fatima Rahman"
                                    : "Muhammad Yusuf"}
                              </div>
                              {index % 4 === 0 && (
                                <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-400">
                                  VIP
                                </Badge>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <div className="space-y-1">
                            <div className="flex items-center">
                              <Mail className="mr-2 h-3 w-3 text-gray-400" />
                              <span>customer{index + 1}@example.com</span>
                            </div>
                            <div className="flex items-center">
                              <Phone className="mr-2 h-3 w-3 text-gray-400" />
                              <span>
                                +966 5{index} {index + 1}23 4567
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          {index % 3 === 0
                            ? "Jeddah, Saudi Arabia"
                            : index % 3 === 1
                              ? "Makkah, Saudi Arabia"
                              : "Madinah, Saudi Arabia"}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 font-medium">{5 + index * 2}</td>
                        <td className="whitespace-nowrap px-4 py-3">2023-11-{10 + index}</td>
                        <td className="whitespace-nowrap px-4 py-3">
                          {index % 4 === 0 ? (
                            <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
                              Active
                            </Badge>
                          ) : index % 4 === 1 ? (
                            <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
                              New
                            </Badge>
                          ) : index % 4 === 2 ? (
                            <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-400">
                              VIP
                            </Badge>
                          ) : (
                            <Badge
                              variant="outline"
                              className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400"
                            >
                              Inactive
                            </Badge>
                          )}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <div className="flex items-center space-x-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Mail className="h-4 w-4 text-gray-500" />
                              <span className="sr-only">Email</span>
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Phone className="h-4 w-4 text-gray-500" />
                              <span className="sr-only">Call</span>
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MessageSquare className="h-4 w-4 text-gray-500" />
                              <span className="sr-only">Message</span>
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">More</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem className="cursor-pointer">View Profile</DropdownMenuItem>
                                <DropdownMenuItem className="cursor-pointer">Edit Customer</DropdownMenuItem>
                                <DropdownMenuItem className="cursor-pointer">Booking History</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="cursor-pointer text-red-600 dark:text-red-400">
                                  Delete Customer
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">10</span> of{" "}
                  <span className="font-medium">2,548</span> customers
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon" disabled>
                    <ChevronLeft className="h-4 w-4" />
                    <span className="sr-only">Previous page</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400"
                  >
                    1
                  </Button>
                  <Button variant="outline" size="sm">
                    2
                  </Button>
                  <Button variant="outline" size="sm">
                    3
                  </Button>
                  <Button variant="outline" size="sm">
                    ...
                  </Button>
                  <Button variant="outline" size="sm">
                    255
                  </Button>
                  <Button variant="outline" size="icon">
                    <ChevronRight className="h-4 w-4" />
                    <span className="sr-only">Next page</span>
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Other tab contents would be similar */}
            <TabsContent value="active" className="mt-0">
              <div className="flex h-40 items-center justify-center rounded-md border border-dashed dark:border-gray-800">
                <p className="text-gray-500 dark:text-gray-400">Active customers would be displayed here</p>
              </div>
            </TabsContent>

            <TabsContent value="inactive" className="mt-0">
              <div className="flex h-40 items-center justify-center rounded-md border border-dashed dark:border-gray-800">
                <p className="text-gray-500 dark:text-gray-400">Inactive customers would be displayed here</p>
              </div>
            </TabsContent>

            <TabsContent value="vip" className="mt-0">
              <div className="flex h-40 items-center justify-center rounded-md border border-dashed dark:border-gray-800">
                <p className="text-gray-500 dark:text-gray-400">VIP customers would be displayed here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

