import { Badge } from "@/components/ui/badge"
import type { Metadata } from "next"
import { Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export const metadata: Metadata = {
  title: "Settings | Umrah Transport Admin",
  description: "Configure system settings for Umrah Transport admin dashboard",
}

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Settings</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Manage your system settings and preferences</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6 space-y-6">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>Update your company details and contact information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="company-name">Company Name</Label>
                  <Input id="company-name" defaultValue="Umrah Transport Services" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-email">Company Email</Label>
                  <Input id="company-email" type="email" defaultValue="info@umrahtransport.com" />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="company-phone">Phone Number</Label>
                  <Input id="company-phone" defaultValue="+966 12 345 6789" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-website">Website</Label>
                  <Input id="company-website" defaultValue="https://umrahtransport.com" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="company-address">Address</Label>
                <Textarea id="company-address" defaultValue="123 King Fahd Road, Makkah, Saudi Arabia" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure general system settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select defaultValue="asia-riyadh">
                    <SelectTrigger id="timezone">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asia-riyadh">Asia/Riyadh (GMT+3)</SelectItem>
                      <SelectItem value="asia-jeddah">Asia/Jeddah (GMT+3)</SelectItem>
                      <SelectItem value="utc">UTC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date-format">Date Format</Label>
                  <Select defaultValue="dd-mm-yyyy">
                    <SelectTrigger id="date-format">
                      <SelectValue placeholder="Select date format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dd-mm-yyyy">DD-MM-YYYY</SelectItem>
                      <SelectItem value="mm-dd-yyyy">MM-DD-YYYY</SelectItem>
                      <SelectItem value="yyyy-mm-dd">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select defaultValue="sar">
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sar">Saudi Riyal (SAR)</SelectItem>
                      <SelectItem value="usd">US Dollar (USD)</SelectItem>
                      <SelectItem value="eur">Euro (EUR)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ar">Arabic</SelectItem>
                      <SelectItem value="ur">Urdu</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Team Members</Label>
                <div className="flex -space-x-2">
                  <Avatar className="h-10 w-10 border-2 border-white dark:border-gray-900">
                    <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                    <AvatarFallback>AD</AvatarFallback>
                  </Avatar>
                  <Avatar className="h-10 w-10 border-2 border-white dark:border-gray-900">
                    <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                    <AvatarFallback>KA</AvatarFallback>
                  </Avatar>
                  <Avatar className="h-10 w-10 border-2 border-white dark:border-gray-900">
                    <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                    <AvatarFallback>MR</AvatarFallback>
                  </Avatar>
                  <Avatar className="h-10 w-10 border-2 border-white dark:border-gray-900">
                    <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                    <AvatarFallback>SA</AvatarFallback>
                  </Avatar>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-assign">Automatic Driver Assignment</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Automatically assign drivers to new bookings based on availability
                    </p>
                  </div>
                  <Switch id="auto-assign" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="booking-confirmation">Automatic Booking Confirmation</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Automatically confirm bookings when payment is received
                    </p>
                  </div>
                  <Switch id="booking-confirmation" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="maintenance-alerts">Maintenance Alerts</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Send alerts when vehicles are due for maintenance
                    </p>
                  </div>
                  <Switch id="maintenance-alerts" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="mt-6 space-y-6">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>Customize the appearance of your dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Color Theme</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-emerald-500 bg-white p-4 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-emerald-800"></div>
                    <div className="mb-2 h-6 w-full rounded-md bg-amber-500"></div>
                    <span className="text-sm font-medium">Gold & Green</span>
                  </div>
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-blue-800"></div>
                    <div className="mb-2 h-6 w-full rounded-md bg-blue-400"></div>
                    <span className="text-sm font-medium">Blue</span>
                  </div>
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-purple-800"></div>
                    <div className="mb-2 h-6 w-full rounded-md bg-pink-400"></div>
                    <span className="text-sm font-medium">Purple</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Display Mode</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-white"></div>
                    <span className="text-sm font-medium">Light</span>
                  </div>
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-gray-900"></div>
                    <span className="text-sm font-medium">Dark</span>
                  </div>
                  <div className="flex cursor-pointer flex-col items-center rounded-md border border-emerald-500 bg-white p-4 dark:bg-gray-950">
                    <div className="mb-2 h-12 w-full rounded-md bg-gradient-to-r from-white to-gray-900"></div>
                    <span className="text-sm font-medium">System</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sidebar-collapsed">Collapsed Sidebar by Default</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Start with a collapsed sidebar for more screen space
                    </p>
                  </div>
                  <Switch id="sidebar-collapsed" />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="animations">Enable Animations</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Show animations and transitions in the interface
                    </p>
                  </div>
                  <Switch id="animations" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="compact-mode">Compact Mode</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Reduce spacing for a more compact interface
                    </p>
                  </div>
                  <Switch id="compact-mode" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6 space-y-6">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Configure how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Email Notifications</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-bookings">New Bookings</Label>
                    <Switch id="email-bookings" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-cancellations">Booking Cancellations</Label>
                    <Switch id="email-cancellations" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-payments">Payment Confirmations</Label>
                    <Switch id="email-payments" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-maintenance">Vehicle Maintenance Alerts</Label>
                    <Switch id="email-maintenance" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-reports">Weekly Reports</Label>
                    <Switch id="email-reports" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">SMS Notifications</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sms-bookings">New Bookings</Label>
                    <Switch id="sms-bookings" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sms-cancellations">Booking Cancellations</Label>
                    <Switch id="sms-cancellations" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sms-urgent">Urgent Alerts Only</Label>
                    <Switch id="sms-urgent" defaultChecked />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">In-App Notifications</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-all">All Activities</Label>
                    <Switch id="app-all" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-sound">Notification Sounds</Label>
                    <Switch id="app-sound" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="app-desktop">Desktop Notifications</Label>
                    <Switch id="app-desktop" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-6 space-y-6">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Manage your account security and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Password</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input id="current-password" type="password" />
                  </div>
                  <div></div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input id="new-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input id="confirm-password" type="password" />
                  </div>
                </div>
                <Button className="mt-2 bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                  Update Password
                </Button>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="two-factor">Enable Two-Factor Authentication</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Add an extra layer of security to your account
                    </p>
                  </div>
                  <Switch id="two-factor" />
                </div>
                <Button variant="outline">Set Up Two-Factor Authentication</Button>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Session Management</h3>
                <div className="rounded-md border dark:border-gray-800">
                  <div className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Current Session</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Chrome on Windows • IP: 192.168.1.1</p>
                      </div>
                      <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
                        Active Now
                      </Badge>
                    </div>
                  </div>
                  <div className="border-t p-4 dark:border-gray-800">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Mobile App</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">iPhone • Last active: 2 hours ago</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Revoke
                      </Button>
                    </div>
                  </div>
                </div>
                <Button variant="outline" className="text-red-600 dark:text-red-400">
                  Log Out All Other Sessions
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

