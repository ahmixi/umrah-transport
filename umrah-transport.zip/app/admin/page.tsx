import type { Metadata } from "next"
import { getDashboardStats } from "@/lib/actions"
import AdminDashboardClient from "@/components/admin/admin-dashboard-client"

export const metadata: Metadata = {
  title: "Admin Dashboard | Umrah Transport",
  description: "Admin dashboard for Umrah Transport services",
}

export default async function AdminDashboard() {
  // Fetch dashboard statistics on the server
  const stats = await getDashboardStats()

  // Pass the pre-fetched data to the client component
  return <AdminDashboardClient initialStats={stats} />
}

