"use client"

import type React from "react"

import { useRef, useEffect, useState } from "react"
import { cn } from "@/lib/utils"

type AnimationType = "fade-in" | "slide-up" | "slide-down" | "slide-left" | "slide-right" | "scale-in"

interface AnimatedSectionProps {
  children: React.ReactNode
  animation: AnimationType
  delay?: number
  className?: string
}

export default function AnimatedSection({ children, animation, delay = 0, className }: AnimatedSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setTimeout(() => {
            setIsVisible(true)
            setHasAnimated(true)
          }, delay * 1000)
        }
      },
      {
        threshold: 0.1,
      },
    )

    const currentRef = sectionRef.current
    if (currentRef) {
      observer.observe(currentRef)
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef)
      }
    }
  }, [delay, hasAnimated])

  const animationClasses = {
    "fade-in": "opacity-0 transition-opacity duration-1000 ease-in-out",
    "slide-up": "opacity-0 translate-y-10 transition-all duration-1000 ease-in-out",
    "slide-down": "opacity-0 -translate-y-10 transition-all duration-1000 ease-in-out",
    "slide-left": "opacity-0 translate-x-10 transition-all duration-1000 ease-in-out",
    "slide-right": "opacity-0 -translate-x-10 transition-all duration-1000 ease-in-out",
    "scale-in": "opacity-0 scale-95 transition-all duration-1000 ease-in-out",
  }

  const visibleClasses = {
    "fade-in": "opacity-100",
    "slide-up": "opacity-100 translate-y-0",
    "slide-down": "opacity-100 translate-y-0",
    "slide-left": "opacity-100 translate-x-0",
    "slide-right": "opacity-100 translate-x-0",
    "scale-in": "opacity-100 scale-100",
  }

  return (
    <div
      ref={sectionRef}
      className={cn(animationClasses[animation], isVisible && visibleClasses[animation], className)}
    >
      {children}
    </div>
  )
}

