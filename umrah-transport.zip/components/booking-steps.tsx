import { Calendar, CreditCard, MapPin } from "lucide-react"

export default function BookingSteps() {
  const steps = [
    {
      icon: <Calendar className="h-10 w-10 text-amber-500" />,
      title: "Choose Your Date & Vehicle",
      description: "Select your travel dates and the type of vehicle that suits your group size and needs.",
    },
    {
      icon: <MapPin className="h-10 w-10 text-amber-500" />,
      title: "Enter Your Details",
      description: "Provide your pickup and drop-off locations along with your contact information.",
    },
    {
      icon: <CreditCard className="h-10 w-10 text-amber-500" />,
      title: "Confirm & Pay",
      description: "Review your booking details and complete your reservation with our secure payment system.",
    },
  ]

  return (
    <div className="grid gap-8 md:grid-cols-3">
      {steps.map((step, index) => (
        <div key={index} className="relative flex flex-col items-center">
          {/* Step number */}
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-800">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-800 text-white">
              {index + 1}
            </div>
          </div>

          {/* Step content */}
          <div className="text-center">
            <div className="mb-4 flex justify-center">{step.icon}</div>
            <h3 className="mb-2 font-serif text-xl font-semibold text-emerald-800">{step.title}</h3>
            <p className="text-gray-600">{step.description}</p>
          </div>

          {/* Connector line */}
          {index < steps.length - 1 && (
            <div
              className="absolute left-1/2 top-8 hidden h-0.5 w-full -translate-y-1/2 transform bg-emerald-200 md:block"
              style={{ left: "75%" }}
            ></div>
          )}
        </div>
      ))}
    </div>
  )
}

