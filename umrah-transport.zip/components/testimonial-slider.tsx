"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const testimonials = [
  {
    id: 1,
    name: "Ahmed Al-Farsi",
    location: "Dubai, UAE",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    rating: 5,
    text: "The service was exceptional from start to finish. Our driver was knowledgeable, respectful, and made our journey comfortable. I highly recommend this service to all pilgrims.",
  },
  {
    id: 2,
    name: "Fatima Rahman",
    location: "London, UK",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    rating: 5,
    text: "As a group of women travelers, we felt safe and respected throughout our journey. The vehicles were immaculate and the drivers were professional. Will definitely use this service again.",
  },
  {
    id: 3,
    name: "Muhammad Yusuf",
    location: "Kuala Lumpur, Malaysia",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    rating: 5,
    text: "The booking process was seamless, and the transportation was punctual and comfortable. The driver was very helpful and accommodating to our needs.",
  },
  {
    id: 4,
    name: "Aisha Malik",
    location: "Toronto, Canada",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    rating: 4,
    text: "Excellent service that made our Umrah journey stress-free. The vehicles were spacious and comfortable, and the drivers were courteous and professional.",
  },
]

export default function TestimonialSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const goToPrevious = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1))
  }

  const goToNext = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prevIndex) => (prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1))
  }

  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        setIsAnimating(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [isAnimating])

  useEffect(() => {
    const interval = setInterval(goToNext, 6000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative mx-auto max-w-4xl px-4">
      <div className="overflow-hidden">
        <div
          className={`flex transition-transform duration-500 ease-in-out ${isAnimating ? "opacity-90" : ""}`}
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="min-w-full px-4">
              <Card className="overflow-hidden border-none bg-white shadow-md">
                <CardContent className="p-8">
                  <div className="flex flex-col items-center text-center">
                    <div className="relative mb-4 h-20 w-20 overflow-hidden rounded-full border-4 border-amber-400">
                      <Image
                        src={testimonial.image || "/placeholder.svg"}
                        alt={testimonial.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="mb-2 flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < testimonial.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="mb-4 text-gray-700">"{testimonial.text}"</p>
                    <h3 className="font-serif text-lg font-semibold text-emerald-800">{testimonial.name}</h3>
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute -left-4 top-1/2 -translate-y-1/2 rounded-full border-emerald-200 bg-white text-emerald-800 shadow-md hover:bg-emerald-50 hover:text-emerald-700 md:-left-8"
        onClick={goToPrevious}
        aria-label="Previous testimonial"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute -right-4 top-1/2 -translate-y-1/2 rounded-full border-emerald-200 bg-white text-emerald-800 shadow-md hover:bg-emerald-50 hover:text-emerald-700 md:-right-8"
        onClick={goToNext}
        aria-label="Next testimonial"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      <div className="mt-6 flex justify-center space-x-2">
        {testimonials.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full transition-all ${
              index === currentIndex ? "w-6 bg-amber-500" : "bg-emerald-200"
            }`}
            onClick={() => setCurrentIndex(index)}
            aria-label={`Go to testimonial ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

