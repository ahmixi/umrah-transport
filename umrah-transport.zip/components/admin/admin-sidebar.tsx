"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutDashboard,
  CalendarClock,
  Users,
  Car,
  CreditCard,
  Settings,
  Bell,
  BarChart,
  MessageSquare,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

interface SidebarItem {
  title: string
  href: string
  icon: React.ReactNode
  submenu?: { title: string; href: string }[]
}

export default function AdminSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null)

  const sidebarItems: SidebarItem[] = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "Bookings",
      href: "/admin/bookings",
      icon: <CalendarClock className="h-5 w-5" />,
      submenu: [
        { title: "All Bookings", href: "/admin/bookings" },
        { title: "Pending", href: "/admin/bookings/pending" },
        { title: "Active", href: "/admin/bookings/active" },
        { title: "Completed", href: "/admin/bookings/completed" },
        { title: "Cancelled", href: "/admin/bookings/cancelled" },
      ],
    },
    {
      title: "Fleet",
      href: "/admin/fleet",
      icon: <Car className="h-5 w-5" />,
      submenu: [
        { title: "All Vehicles", href: "/admin/fleet" },
        { title: "Maintenance", href: "/admin/fleet/maintenance" },
        { title: "GPS Tracking", href: "/admin/fleet/tracking" },
      ],
    },
    {
      title: "Drivers",
      href: "/admin/drivers",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Customers",
      href: "/admin/customers",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Payments",
      href: "/admin/payments",
      icon: <CreditCard className="h-5 w-5" />,
      submenu: [
        { title: "Transactions", href: "/admin/payments" },
        { title: "Invoices", href: "/admin/payments/invoices" },
        { title: "Reports", href: "/admin/payments/reports" },
      ],
    },
    {
      title: "Analytics",
      href: "/admin/analytics",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Messages",
      href: "/admin/messages",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      title: "Notifications",
      href: "/admin/notifications",
      icon: <Bell className="h-5 w-5" />,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: <Settings className="h-5 w-5" />,
      submenu: [
        { title: "General", href: "/admin/settings" },
        { title: "User Roles", href: "/admin/settings/roles" },
        { title: "Appearance", href: "/admin/settings/appearance" },
        { title: "Notifications", href: "/admin/settings/notifications" },
      ],
    },
  ]

  const toggleSubmenu = (title: string) => {
    setOpenSubmenu(openSubmenu === title ? null : title)
  }

  const isActive = (href: string) => {
    return pathname === href
  }

  return (
    <div
      className={cn(
        "relative flex h-screen flex-col border-r bg-white transition-all duration-300 dark:border-gray-800 dark:bg-gray-950",
        collapsed ? "w-[70px]" : "w-[250px]",
      )}
    >
      <div className="flex h-16 items-center border-b px-4 dark:border-gray-800">
        <Link href="/admin" className="flex items-center">
          {!collapsed ? (
            <div className="flex items-center">
              <div className="mr-2 rounded-full bg-emerald-100 p-1 dark:bg-emerald-900">
                <Car className="h-6 w-6 text-emerald-800 dark:text-emerald-400" />
              </div>
              <span className="font-serif text-xl font-bold text-emerald-800 dark:text-emerald-400">Umrah Admin</span>
            </div>
          ) : (
            <div className="flex w-full justify-center">
              <div className="rounded-full bg-emerald-100 p-1 dark:bg-emerald-900">
                <Car className="h-6 w-6 text-emerald-800 dark:text-emerald-400" />
              </div>
            </div>
          )}
        </Link>
      </div>

      <ScrollArea className="flex-1 py-4">
        <nav className="space-y-1 px-2">
          {sidebarItems.map((item) => (
            <div key={item.title} className="space-y-1">
              {item.submenu ? (
                <>
                  <button
                    onClick={() => toggleSubmenu(item.title)}
                    className={cn(
                      "flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition-colors",
                      isActive(item.href)
                        ? "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/50 dark:text-emerald-400"
                        : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                    )}
                  >
                    <div className="flex items-center">
                      {item.icon}
                      {!collapsed && <span className="ml-3">{item.title}</span>}
                    </div>
                    {!collapsed && (
                      <ChevronRight
                        className={cn("h-4 w-4 transition-transform", openSubmenu === item.title && "rotate-90")}
                      />
                    )}
                  </button>
                  {!collapsed && openSubmenu === item.title && (
                    <div className="ml-4 mt-1 space-y-1 border-l border-gray-200 pl-3 dark:border-gray-700">
                      {item.submenu.map((subItem) => (
                        <Link
                          key={subItem.title}
                          href={subItem.href}
                          className={cn(
                            "block rounded-md px-3 py-2 text-sm font-medium transition-colors",
                            isActive(subItem.href)
                              ? "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/50 dark:text-emerald-400"
                              : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                          )}
                        >
                          {subItem.title}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    isActive(item.href)
                      ? "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/50 dark:text-emerald-400"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800",
                  )}
                >
                  {item.icon}
                  {!collapsed && <span className="ml-3">{item.title}</span>}
                </Link>
              )}
            </div>
          ))}
        </nav>
      </ScrollArea>

      <div className="border-t p-4 dark:border-gray-800">
        <Link
          href="/admin/logout"
          className={cn(
            "flex items-center rounded-md px-3 py-2 text-sm font-medium text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20",
            collapsed && "justify-center",
          )}
        >
          <LogOut className="h-5 w-5" />
          {!collapsed && <span className="ml-3">Logout</span>}
        </Link>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-4 top-20 z-10 flex h-8 w-8 items-center justify-center rounded-full border bg-white shadow-md dark:border-gray-800 dark:bg-gray-950"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </Button>
    </div>
  )
}

