"use client"
import { useEffect, useState } from "react"
import { CheckCircle, Clock, AlertCircle, XCircle, MoreHorizontal, Eye, Edit, Trash, MessageSquare } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { getBookings, updateBookingStatus, type Booking, type BookingStatus } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"

const getStatusBadge = (status: BookingStatus) => {
  switch (status) {
    case "completed":
      return (
        <Badge className="flex items-center gap-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
          <CheckCircle className="h-3 w-3" />
          <span>Completed</span>
        </Badge>
      )
    case "in-progress":
      return (
        <Badge
          variant="outline"
          className="flex items-center gap-1 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400"
        >
          <Clock className="h-3 w-3" />
          <span>In Progress</span>
        </Badge>
      )
    case "pending":
      return (
        <Badge
          variant="outline"
          className="flex items-center gap-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-400"
        >
          <AlertCircle className="h-3 w-3" />
          <span>Pending</span>
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="destructive" className="flex items-center gap-1">
          <XCircle className="h-3 w-3" />
          <span>Cancelled</span>
        </Badge>
      )
    default:
      return (
        <Badge variant="outline">
          <span>{status}</span>
        </Badge>
      )
  }
}

export function RecentBookings() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    async function fetchBookings() {
      try {
        const data = await getBookings()
        setBookings(data.slice(0, 5)) // Get only the 5 most recent bookings
      } catch (error) {
        console.error("Error fetching bookings:", error)
        toast({
          title: "Error",
          description: "Failed to load recent bookings",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchBookings()

    // Set up polling for real-time updates
    const interval = setInterval(fetchBookings, 30000) // Poll every 30 seconds
    return () => clearInterval(interval)
  }, [toast])

  const handleStatusChange = async (bookingId: string, newStatus: BookingStatus) => {
    try {
      const result = await updateBookingStatus(bookingId, newStatus)
      if (result.success) {
        setBookings(bookings.map((booking) => (booking.id === bookingId ? { ...booking, status: newStatus } : booking)))
        toast({
          title: "Status Updated",
          description: `Booking status changed to ${newStatus}`,
        })
      } else {
        toast({
          title: "Update Failed",
          description: result.error || "Failed to update booking status",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error updating booking status:", error)
      toast({
        title: "Error",
        description: "Failed to update booking status",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center p-4">
        <Clock className="h-6 w-6 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b text-left text-xs font-medium text-gray-500 dark:border-gray-800 dark:text-gray-400">
            <th className="px-4 py-3">Booking</th>
            <th className="px-4 py-3">Customer</th>
            <th className="px-4 py-3">Date & Time</th>
            <th className="px-4 py-3">Route</th>
            <th className="px-4 py-3">Vehicle</th>
            <th className="px-4 py-3">Amount</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y dark:divide-gray-800">
          {bookings.map((booking) => (
            <tr
              key={booking.id}
              className="text-sm text-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800/50"
            >
              <td className="whitespace-nowrap px-4 py-3 font-medium">{booking.id}</td>
              <td className="whitespace-nowrap px-4 py-3">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
                    <AvatarFallback>{booking.customerName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span>{booking.customerName}</span>
                </div>
              </td>
              <td className="whitespace-nowrap px-4 py-3">
                <div className="flex flex-col">
                  <span>{booking.date}</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">{booking.time}</span>
                </div>
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-col">
                  <span className="font-medium">From: {booking.pickupLocation}</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">To: {booking.dropoffLocation}</span>
                </div>
              </td>
              <td className="whitespace-nowrap px-4 py-3">
                {booking.vehicleType === "sedan"
                  ? "Luxury Sedan"
                  : booking.vehicleType === "suv"
                    ? "Executive SUV"
                    : booking.vehicleType === "van"
                      ? "Premium Van"
                      : "Luxury Bus"}
              </td>
              <td className="whitespace-nowrap px-4 py-3 font-medium">{booking.amount}</td>
              <td className="whitespace-nowrap px-4 py-3">{getStatusBadge(booking.status)}</td>
              <td className="whitespace-nowrap px-4 py-3">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Actions</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="cursor-pointer">
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Booking
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Contact Customer
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    {booking.status === "pending" && (
                      <DropdownMenuItem
                        className="cursor-pointer text-emerald-600 dark:text-emerald-400"
                        onClick={() => handleStatusChange(booking.id, "confirmed")}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Confirm Booking
                      </DropdownMenuItem>
                    )}
                    {(booking.status === "pending" || booking.status === "confirmed") && (
                      <DropdownMenuItem
                        className="cursor-pointer text-amber-600 dark:text-amber-400"
                        onClick={() => handleStatusChange(booking.id, "in-progress")}
                      >
                        <Clock className="mr-2 h-4 w-4" />
                        Mark In Progress
                      </DropdownMenuItem>
                    )}
                    {booking.status === "in-progress" && (
                      <DropdownMenuItem
                        className="cursor-pointer text-emerald-600 dark:text-emerald-400"
                        onClick={() => handleStatusChange(booking.id, "completed")}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Mark Completed
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      className="cursor-pointer text-red-600 dark:text-red-400"
                      onClick={() => handleStatusChange(booking.id, "cancelled")}
                    >
                      <Trash className="mr-2 h-4 w-4" />
                      Cancel Booking
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

