"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Users,
  Car,
  CreditCard,
  TrendingUp,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
  ArrowUpRight,
  Download,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { OverviewChart } from "@/components/admin/overview-chart"
import { RevenueChart } from "@/components/admin/revenue-chart"
import { RecentBookings } from "@/components/admin/recent-bookings"
import { DriverActivity } from "@/components/admin/driver-activity"
import { Suspense } from "react"

// Define the type for the stats prop
interface DashboardStats {
  totalBookings: number
  activeRides: number
  totalRevenue: string
  customerSatisfaction: string
  bookingStatus: {
    completed: number
    inProgress: number
    pending: number
    cancelled: number
  }
  vehicleAvailability: {
    available: number
    inUse: number
    maintenance: number
    inactive: number
  }
}

interface AdminDashboardClientProps {
  initialStats: DashboardStats
}

export default function AdminDashboardClient({ initialStats }: AdminDashboardClientProps) {
  // Use the pre-fetched stats passed from the server component
  const stats = initialStats

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Download className="mr-2 h-4 w-4" />
            Download Report
          </Button>
          <Button className="bg-emerald-800 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600">
            View Analytics
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Bookings</CardTitle>
            <div className="rounded-full bg-emerald-100 p-2 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
              <Calendar className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.totalBookings}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              <span className="inline-flex items-center text-emerald-600 dark:text-emerald-400">
                <ArrowUpRight className="mr-1 h-3 w-3" /> +12.5%
              </span>{" "}
              from last month
            </p>
            <Progress value={75} className="mt-3 h-1 bg-gray-200 dark:bg-gray-700" indicatorColor="bg-emerald-600" />
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Rides</CardTitle>
            <div className="rounded-full bg-amber-100 p-2 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
              <Car className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.activeRides}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              <span className="inline-flex items-center text-amber-600 dark:text-amber-400">
                <Clock className="mr-1 h-3 w-3" /> 8 arriving soon
              </span>
            </p>
            <Progress value={42} className="mt-3 h-1 bg-gray-200 dark:bg-gray-700" indicatorColor="bg-amber-500" />
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Revenue</CardTitle>
            <div className="rounded-full bg-emerald-100 p-2 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">
              <CreditCard className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.totalRevenue}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              <span className="inline-flex items-center text-emerald-600 dark:text-emerald-400">
                <ArrowUpRight className="mr-1 h-3 w-3" /> +18.2%
              </span>{" "}
              from last month
            </p>
            <Progress value={85} className="mt-3 h-1 bg-gray-200 dark:bg-gray-700" indicatorColor="bg-emerald-600" />
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">
              Customer Satisfaction
            </CardTitle>
            <div className="rounded-full bg-amber-100 p-2 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.customerSatisfaction}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              <span className="inline-flex items-center text-amber-600 dark:text-amber-400">
                <ArrowUpRight className="mr-1 h-3 w-3" /> +0.3
              </span>{" "}
              from last month
            </p>
            <Progress value={96} className="mt-3 h-1 bg-gray-200 dark:bg-gray-700" indicatorColor="bg-amber-500" />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="border-none shadow-md lg:col-span-4">
          <CardHeader>
            <CardTitle>Business Overview</CardTitle>
            <CardDescription>View your business performance over time</CardDescription>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div className="h-[300px] flex items-center justify-center">Loading chart...</div>}>
              <OverviewChart />
            </Suspense>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md lg:col-span-3">
          <CardHeader>
            <CardTitle>Revenue Breakdown</CardTitle>
            <CardDescription>Revenue by vehicle type</CardDescription>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div className="h-[300px] flex items-center justify-center">Loading chart...</div>}>
              <RevenueChart />
            </Suspense>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-none shadow-md lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Bookings</CardTitle>
              <CardDescription>Latest booking activities</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <a href="/admin/bookings">View All</a>
            </Button>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div className="h-[300px] flex items-center justify-center">Loading bookings...</div>}>
              <RecentBookings />
            </Suspense>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Driver Activity</CardTitle>
              <CardDescription>Top performing drivers</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <a href="/admin/drivers">View All</a>
            </Button>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div className="h-[300px] flex items-center justify-center">Loading drivers...</div>}>
              <DriverActivity />
            </Suspense>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Booking Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-emerald-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Completed</span>
              </div>
              <span className="font-medium">{stats.bookingStatus.completed}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-amber-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">In Progress</span>
              </div>
              <span className="font-medium">{stats.bookingStatus.inProgress}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-blue-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Pending</span>
              </div>
              <span className="font-medium">{stats.bookingStatus.pending}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Cancelled</span>
              </div>
              <span className="font-medium">{stats.bookingStatus.cancelled}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Vehicle Availability</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-emerald-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Available</span>
              </div>
              <span className="font-medium">{stats.vehicleAvailability.available}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-amber-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">In Use</span>
              </div>
              <span className="font-medium">{stats.vehicleAvailability.inUse}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Maintenance</span>
              </div>
              <span className="font-medium">{stats.vehicleAvailability.maintenance}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-gray-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Inactive</span>
              </div>
              <span className="font-medium">{stats.vehicleAvailability.inactive}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Payment Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-emerald-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Paid</span>
              </div>
              <span className="font-medium">924</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-amber-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Pending</span>
              </div>
              <span className="font-medium">86</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Failed</span>
              </div>
              <span className="font-medium">12</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-2 h-3 w-3 rounded-full bg-purple-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Refunded</span>
              </div>
              <span className="font-medium">18</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Recent Alerts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between rounded-lg bg-red-50 p-2 dark:bg-red-900/20">
              <div className="flex items-center">
                <AlertCircle className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">Vehicle Maintenance Due</span>
              </div>
              <Badge variant="destructive">3</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-amber-50 p-2 dark:bg-amber-900/20">
              <div className="flex items-center">
                <Clock className="mr-2 h-4 w-4 text-amber-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">Pending Approvals</span>
              </div>
              <Badge variant="outline" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
                8
              </Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-emerald-50 p-2 dark:bg-emerald-900/20">
              <div className="flex items-center">
                <CheckCircle className="mr-2 h-4 w-4 text-emerald-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">New Bookings</span>
              </div>
              <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">12</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-blue-50 p-2 dark:bg-blue-900/20">
              <div className="flex items-center">
                <TrendingUp className="mr-2 h-4 w-4 text-blue-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">Revenue Target</span>
              </div>
              <Badge variant="outline" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-400">
                92%
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

