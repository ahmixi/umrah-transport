"use client"

import { useTheme } from "next-themes"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const data = [
  { name: "Jan", bookings: 65, revenue: 24000, satisfaction: 4.2 },
  { name: "Feb", bookings: 59, revenue: 22000, satisfaction: 4.3 },
  { name: "Mar", bookings: 80, revenue: 29000, satisfaction: 4.4 },
  { name: "Apr", bookings: 81, revenue: 30000, satisfaction: 4.5 },
  { name: "May", bookings: 56, revenue: 21000, satisfaction: 4.6 },
  { name: "Jun", bookings: 55, revenue: 20000, satisfaction: 4.7 },
  { name: "Jul", bookings: 40, revenue: 15000, satisfaction: 4.5 },
  { name: "Aug", bookings: 70, revenue: 25000, satisfaction: 4.6 },
  { name: "Sep", bookings: 90, revenue: 32000, satisfaction: 4.7 },
  { name: "Oct", bookings: 110, revenue: 38000, satisfaction: 4.8 },
  { name: "Nov", bookings: 120, revenue: 42000, satisfaction: 4.8 },
  { name: "Dec", bookings: 130, revenue: 45000, satisfaction: 4.9 },
]

export function OverviewChart() {
  const { theme } = useTheme()
  const isDark = theme === "dark"

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? "#374151" : "#e5e7eb"} />
          <XAxis
            dataKey="name"
            stroke={isDark ? "#9ca3af" : "#6b7280"}
            tick={{ fill: isDark ? "#9ca3af" : "#6b7280" }}
          />
          <YAxis
            yAxisId="left"
            stroke={isDark ? "#9ca3af" : "#6b7280"}
            tick={{ fill: isDark ? "#9ca3af" : "#6b7280" }}
          />
          <YAxis
            yAxisId="right"
            orientation="right"
            stroke={isDark ? "#9ca3af" : "#6b7280"}
            tick={{ fill: isDark ? "#9ca3af" : "#6b7280" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: isDark ? "#1f2937" : "#ffffff",
              borderColor: isDark ? "#374151" : "#e5e7eb",
              color: isDark ? "#e5e7eb" : "#111827",
            }}
          />
          <Legend />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="bookings"
            stroke="#10b981"
            activeDot={{ r: 8 }}
            strokeWidth={2}
          />
          <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

