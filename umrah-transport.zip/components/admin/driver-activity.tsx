"use client"

import { useEffect, useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { getDrivers, type Driver } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"

const getStatusBadge = (status: Driver["status"]) => {
  switch (status) {
    case "active":
      return <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-400">Active</Badge>
    case "idle":
      return (
        <Badge variant="outline" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-400">
          Idle
        </Badge>
      )
    case "offline":
      return (
        <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400">
          Offline
        </Badge>
      )
  }
}

export function DriverActivity() {
  const [drivers, setDrivers] = useState<Driver[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    async function fetchDrivers() {
      try {
        const data = await getDrivers()
        setDrivers(data)
      } catch (error) {
        console.error("Error fetching drivers:", error)
        toast({
          title: "Error",
          description: "Failed to load driver data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchDrivers()
  }, [toast])

  if (loading) {
    return (
      <div className="flex justify-center p-4">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-emerald-600 border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {drivers.map((driver) => (
        <div key={driver.id} className="flex items-center justify-between rounded-lg border p-4 dark:border-gray-800">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg" />
              <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium">{driver.name}</h3>
                {getStatusBadge(driver.status)}
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                <span>{driver.vehicle}</span>
                <span>•</span>
                <span>{driver.completedTrips} trips</span>
                <span>•</span>
                <div className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="mr-1 h-3 w-3 text-amber-500"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                      clipRule="evenodd"
                    />
                  </svg>
                  {driver.rating}
                </div>
              </div>
            </div>
          </div>
          <div className="flex w-24 flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500 dark:text-gray-400">Performance</span>
              <span className="font-medium">{driver.rating * 20}%</span>
            </div>
            <Progress value={driver.rating * 20} className="h-1.5" indicatorColor="bg-emerald-600" />
          </div>
        </div>
      ))}
    </div>
  )
}

