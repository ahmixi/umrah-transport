"use client"

import { useState, useEffect, useCallback } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

// Define vehicles data with string-based icons
const vehicles = [
  {
    id: 1,
    name: "Luxury Sedan",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    capacity: "3 passengers",
    features: ["Air Conditioning", "Leather Seats", "WiFi", "Bottled Water"],
    type: "sedan",
  },
  {
    id: 2,
    name: "Executive SUV",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    capacity: "6 passengers",
    features: ["Air Conditioning", "Leather Seats", "WiFi", "Bottled Water", "Extra Luggage Space"],
    type: "suv",
  },
  {
    id: 3,
    name: "Premium Van",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    capacity: "12 passengers",
    features: ["Air Conditioning", "Comfortable Seating", "WiFi", "Bottled Water", "Ample Luggage Space"],
    type: "van",
  },
  {
    id: 4,
    name: "Luxury Bus",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-17%20at%2012.26.01%20PM-FywW4wnNmDZTCTMFFIGKMLS377M65v.jpeg",
    capacity: "30 passengers",
    features: ["Air Conditioning", "Reclining Seats", "WiFi", "Bottled Water", "Restroom", "Entertainment System"],
    type: "bus",
  },
]

export default function VehicleCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [direction, setDirection] = useState<"left" | "right" | null>(null)

  const goToPrevious = useCallback(() => {
    if (isAnimating) return
    setDirection("left")
    setIsAnimating(true)
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? vehicles.length - 1 : prevIndex - 1))
  }, [isAnimating])

  const goToNext = useCallback(() => {
    if (isAnimating) return
    setDirection("right")
    setIsAnimating(true)
    setCurrentIndex((prevIndex) => (prevIndex === vehicles.length - 1 ? 0 : prevIndex + 1))
  }, [isAnimating])

  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        setIsAnimating(false)
        setDirection(null)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [isAnimating])

  useEffect(() => {
    const interval = setInterval(goToNext, 5000)
    return () => clearInterval(interval)
  }, [goToNext])

  const getAnimationClass = (index: number) => {
    if (!isAnimating) return "opacity-100 translate-x-0"
    if (index === currentIndex) {
      return direction === "right" ? "animate-slide-in-right" : "animate-slide-in-left"
    }
    return "opacity-0"
  }

  return (
    <div className="relative overflow-hidden rounded-lg bg-white p-6 shadow-lg">
      <div className="relative h-[400px] overflow-hidden">
        {vehicles.map((vehicle, index) => (
          <div
            key={vehicle.id}
            className={`absolute inset-0 transition-all duration-500 ${
              index === currentIndex ? getAnimationClass(index) : "opacity-0"
            }`}
            style={{ display: index === currentIndex ? "block" : "none" }}
          >
            <div className="grid gap-6 md:grid-cols-2">
              <div className="relative h-[300px] overflow-hidden rounded-lg md:h-full">
                <Image src={vehicle.image || "/placeholder.svg"} alt={vehicle.name} fill className="object-cover" />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="mb-2 font-serif text-2xl font-bold text-emerald-800">{vehicle.name}</h3>
                <p className="mb-4 text-lg text-gray-600">Capacity: {vehicle.capacity}</p>
                <div className="mb-6">
                  <h4 className="mb-2 font-semibold text-emerald-700">Features:</h4>
                  <ul className="grid grid-cols-2 gap-2">
                    {vehicle.features.map((feature, i) => (
                      <li key={i} className="flex items-center text-gray-600">
                        <div className="mr-2 h-2 w-2 rounded-full bg-amber-400"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                <Link href={`/booking?vehicle=${vehicle.type}`}>
                  <Button className="w-fit bg-emerald-800 hover:bg-emerald-700">Book This Vehicle</Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="absolute bottom-6 left-0 right-0 flex justify-center space-x-2">
        {vehicles.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full transition-all ${
              index === currentIndex ? "w-6 bg-amber-500" : "bg-emerald-200"
            }`}
            onClick={() => setCurrentIndex(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full border-emerald-200 bg-white/80 text-emerald-800 backdrop-blur-sm hover:bg-white hover:text-emerald-700"
        onClick={goToPrevious}
        aria-label="Previous vehicle"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full border-emerald-200 bg-white/80 text-emerald-800 backdrop-blur-sm hover:bg-white hover:text-emerald-700"
        onClick={goToNext}
        aria-label="Next vehicle"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  )
}

