"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import AnimatedSection from "@/components/animated-section"
import { Users, Briefcase, Wifi, Thermometer, Music } from "lucide-react"

// Helper function to render the appropriate icon
const getIconComponent = (iconName: string) => {
  switch (iconName) {
    case "thermometer":
      return <Thermometer className="h-5 w-5" />
    case "wifi":
      return <Wifi className="h-5 w-5" />
    case "music":
      return <Music className="h-5 w-5" />
    case "briefcase":
      return <Briefcase className="h-5 w-5" />
    case "users":
      return <Users className="h-5 w-5" />
    default:
      return null
  }
}

interface VehicleCardProps {
  vehicle: {
    id: string
    name: string
    description: string
    capacity: string
    luggage: string
    image: string
    features: { icon: string; name: string }[]
    models: string[]
    price: string
  }
  index: number
}

export default function VehicleCard({ vehicle, index }: VehicleCardProps) {
  return (
    <div id={vehicle.id} className="scroll-mt-20">
      <AnimatedSection animation={index % 2 === 0 ? "slide-right" : "slide-left"}>
        <div className={`grid gap-8 md:grid-cols-2 ${index % 2 === 1 ? "md:grid-flow-dense" : ""}`}>
          <div className={`${index % 2 === 1 ? "md:col-start-2" : ""}`}>
            <h2 className="mb-2 font-serif text-2xl font-bold text-emerald-800 md:text-3xl">{vehicle.name}</h2>
            <p className="mb-4 text-gray-600">{vehicle.description}</p>

            <div className="mb-6 grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-emerald-50 p-4">
                <div className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-emerald-600" />
                  <span className="font-medium text-emerald-800">Capacity</span>
                </div>
                <p className="mt-1 text-gray-600">{vehicle.capacity}</p>
              </div>
              <div className="rounded-lg bg-emerald-50 p-4">
                <div className="flex items-center">
                  <Briefcase className="mr-2 h-5 w-5 text-emerald-600" />
                  <span className="font-medium text-emerald-800">Luggage</span>
                </div>
                <p className="mt-1 text-gray-600">{vehicle.luggage}</p>
              </div>
            </div>

            <h3 className="mb-3 font-serif text-lg font-semibold text-emerald-700">Features:</h3>
            <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {vehicle.features.map((feature, i) => (
                <div key={i} className="flex items-center">
                  <div className="mr-2 rounded-full bg-amber-100 p-1 text-amber-600">
                    {getIconComponent(feature.icon)}
                  </div>
                  <span className="text-sm text-gray-600">{feature.name}</span>
                </div>
              ))}
            </div>

            <h3 className="mb-2 font-serif text-lg font-semibold text-emerald-700">Available Models:</h3>
            <ul className="mb-6 list-inside list-disc space-y-1 text-gray-600">
              {vehicle.models.map((model, i) => (
                <li key={i}>{model}</li>
              ))}
            </ul>

            <div className="mb-6 flex items-baseline">
              <span className="text-lg font-bold text-emerald-800">{vehicle.price}</span>
              <span className="ml-2 text-sm text-gray-500">per day</span>
            </div>

            <Link href={`/booking?vehicle=${vehicle.id}`}>
              <Button className="bg-emerald-800 hover:bg-emerald-700">Book This Vehicle</Button>
            </Link>
          </div>

          <div className={`${index % 2 === 1 ? "md:col-start-1" : ""}`}>
            <div className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src={vehicle.image || "/placeholder.svg"}
                alt={vehicle.name}
                width={600}
                height={400}
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </AnimatedSection>
    </div>
  )
}

