"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CalendarIcon, CheckCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { zodResolver } from "@hookform/resolvers/zod"
import { format } from "date-fns"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { createBooking } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number.",
  }),
  date: z.date({
    required_error: "Please select a date.",
  }),
  passengers: z.string().min(1, {
    message: "Please select the number of passengers.",
  }),
  vehicleType: z.string().min(1, {
    message: "Please select a vehicle type.",
  }),
  pickupLocation: z.string().min(3, {
    message: "Pickup location must be at least 3 characters.",
  }),
  dropoffLocation: z.string().min(3, {
    message: "Drop-off location must be at least 3 characters.",
  }),
  specialRequirements: z.string().optional(),
})

export default function BookingForm() {
  const router = useRouter()
  const { toast } = useToast()

  // State for vehicle type from URL
  const [initialVehicleType, setInitialVehicleType] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const totalSteps = 3

  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      passengers: "",
      vehicleType: "",
      pickupLocation: "",
      dropoffLocation: "",
      specialRequirements: "",
    },
    mode: "onChange",
  })

  // Get vehicle type from URL when component mounts
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search)
      const vehicleParam = params.get("vehicle")
      if (vehicleParam) {
        setInitialVehicleType(vehicleParam)
        form.setValue("vehicleType", vehicleParam)
      }
    }
  }, [form])

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    try {
      // Create FormData object to pass to server action
      const formData = new FormData()
      formData.append("name", values.name)
      formData.append("email", values.email)
      formData.append("phone", values.phone)
      formData.append("date", format(values.date, "yyyy-MM-dd"))
      formData.append("time", "09:00 AM") // Default time
      formData.append("passengers", values.passengers)
      formData.append("vehicleType", values.vehicleType)
      formData.append("pickupLocation", values.pickupLocation)
      formData.append("dropoffLocation", values.dropoffLocation)
      if (values.specialRequirements) {
        formData.append("specialRequirements", values.specialRequirements)
      }

      // Submit booking to server
      const result = await createBooking(formData)

      if (result.success) {
        setIsSuccess(true)
        toast({
          title: "Booking Confirmed!",
          description: "Your booking has been successfully submitted. We'll contact you shortly.",
        })

        // Reset form after 3 seconds
        setTimeout(() => {
          setIsSuccess(false)
          form.reset()
          setCurrentStep(1)
          router.refresh() // Refresh the page to update any data
        }, 3000)
      } else {
        toast({
          title: "Booking Failed",
          description: result.error || "There was an error processing your booking. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Booking submission error:", error)
      toast({
        title: "Booking Failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle next step
  const handleNextStep = async () => {
    let fieldsToValidate: string[] = []

    if (currentStep === 1) {
      fieldsToValidate = ["date", "vehicleType", "passengers"]
    } else if (currentStep === 2) {
      fieldsToValidate = ["pickupLocation", "dropoffLocation"]
    }

    const isValid = await form.trigger(fieldsToValidate as any)

    if (isValid) {
      setCurrentStep((prev) => Math.min(prev + 1, totalSteps))
    }
  }

  // Handle previous step
  const handlePrevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1))
  }

  return (
    <div className="relative">
      {/* Progress indicator */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-2xl font-bold text-emerald-800">Book Your Transportation</h3>
          <span className="text-sm text-emerald-600">
            Step {currentStep} of {totalSteps}
          </span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-emerald-100">
          <div
            className="h-full rounded-full bg-emerald-600 transition-all duration-700 ease-in-out"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
      </div>

      {isSuccess ? (
        <div className="animate-fade-in rounded-lg bg-emerald-50 p-8 text-center">
          <div className="mb-4 flex justify-center">
            <div className="rounded-full bg-emerald-100 p-3">
              <CheckCircle className="h-10 w-10 text-emerald-600 animate-pulse" />
            </div>
          </div>
          <h4 className="mb-2 text-xl font-semibold text-emerald-800">Booking Confirmed!</h4>
          <p className="text-emerald-600 mb-4">
            Thank you for your booking. We will contact you shortly to confirm your reservation.
          </p>
          <p className="text-sm text-emerald-700">A confirmation email has been sent to your email address.</p>
        </div>
      ) : (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            {currentStep === 1 && (
              <div className="space-y-5 animate-fadeIn">
                <h4 className="font-medium text-emerald-800">Step 1: Choose Your Date & Vehicle</h4>

                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Date of Service</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal transition-all duration-300",
                                !field.value && "text-muted-foreground",
                              )}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Select your travel date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 animate-fadeIn" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                            className="rounded-md border border-emerald-200 shadow-lg"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="vehicleType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vehicle Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select vehicle type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="animate-fadeIn">
                          <SelectItem value="sedan">Luxury Sedan (up to 3 passengers)</SelectItem>
                          <SelectItem value="suv">Executive SUV (up to 6 passengers)</SelectItem>
                          <SelectItem value="van">Premium Van (up to 12 passengers)</SelectItem>
                          <SelectItem value="bus">Luxury Bus (up to 30 passengers)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="passengers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Passengers</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select number of passengers" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="animate-fadeIn">
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "11-15", "16-20", "21-30", "30+"].map((num) => (
                            <SelectItem key={num} value={String(num)}>
                              {num} {typeof num === "number" && num === 1 ? "passenger" : "passengers"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-5 animate-fadeIn">
                <h4 className="font-medium text-emerald-800">Step 2: Enter Your Trip Details</h4>

                <FormField
                  control={form.control}
                  name="pickupLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pickup Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Hotel name, airport, or address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="dropoffLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Drop-off Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Hotel name, airport, or address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="specialRequirements"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Special Requirements (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any special requests or requirements"
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-5 animate-fadeIn">
                <h4 className="font-medium text-emerald-800">Step 3: Your Contact Information</h4>

                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="john@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 234 567 8900" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="rounded-lg bg-amber-50 p-4 text-sm text-amber-800">
                  <p>
                    By submitting this form, you agree to our{" "}
                    <a href="#" className="underline">
                      Terms of Service
                    </a>{" "}
                    and{" "}
                    <a href="#" className="underline">
                      Privacy Policy
                    </a>
                    .
                  </p>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-4">
              {currentStep > 1 ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handlePrevStep}
                  className="border-emerald-200 text-emerald-800 hover:bg-emerald-50"
                >
                  Previous
                </Button>
              ) : (
                <div></div>
              )}

              {currentStep < totalSteps ? (
                <Button type="button" onClick={handleNextStep} className="bg-emerald-800 hover:bg-emerald-700">
                  Continue
                </Button>
              ) : (
                <Button type="submit" className="bg-emerald-800 hover:bg-emerald-700" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <div className="flex items-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      <span>Processing...</span>
                    </div>
                  ) : (
                    "Complete Booking"
                  )}
                </Button>
              )}
            </div>
          </form>
        </Form>
      )}
    </div>
  )
}

