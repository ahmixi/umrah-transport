"use server"

import { revalidatePath } from "next/cache"

// Types for our data
export type BookingStatus = "pending" | "confirmed" | "in-progress" | "completed" | "cancelled"

export interface Booking {
  id: string
  customerName: string
  customerEmail: string
  customerPhone: string
  date: string
  time: string
  passengers: string
  vehicleType: string
  pickupLocation: string
  dropoffLocation: string
  specialRequirements?: string
  status: BookingStatus
  amount: string
  createdAt: string
  driverId?: string
}

export interface Customer {
  id: string
  name: string
  email: string
  phone: string
  totalBookings: number
  lastBookingDate?: string
  status: "active" | "inactive" | "new" | "vip"
}

export interface Vehicle {
  id: string
  name: string
  type: string
  licensePlate: string
  status: "available" | "in-use" | "maintenance" | "inactive"
  driver?: string
  location?: string
  lastService: string
  nextService: string
  fuelLevel: number
}

export interface Driver {
  id: string
  name: string
  status: "active" | "idle" | "offline"
  completedTrips: number
  rating: number
  vehicle: string
}

// In a real application, these would be database calls
// For this demo, we'll use in-memory storage
const bookings: Booking[] = [
  {
    id: "B-1001",
    customerName: "Ahmed Al-Farsi",
    customerEmail: "ahmed@example.com",
    customerPhone: "+966 50 123 4567",
    date: "2023-11-15",
    time: "09:30 AM",
    passengers: "3",
    vehicleType: "sedan",
    pickupLocation: "Jeddah Airport",
    dropoffLocation: "Makkah Hotel",
    specialRequirements: "Extra luggage space needed",
    status: "completed",
    amount: "SAR 350",
    createdAt: "2023-11-10T12:00:00Z",
    driverId: "D-1001",
  },
  {
    id: "B-1002",
    customerName: "Fatima Rahman",
    customerEmail: "fatima@example.com",
    customerPhone: "+966 50 987 6543",
    date: "2023-11-15",
    time: "10:45 AM",
    passengers: "6",
    vehicleType: "suv",
    pickupLocation: "Makkah Hotel",
    dropoffLocation: "Masjid al-Haram",
    specialRequirements: "",
    status: "in-progress",
    amount: "SAR 250",
    createdAt: "2023-11-12T14:30:00Z",
    driverId: "D-1002",
  },
  {
    id: "B-1003",
    customerName: "Muhammad Yusuf",
    customerEmail: "muhammad@example.com",
    customerPhone: "+966 55 456 7890",
    date: "2023-11-16",
    time: "08:15 AM",
    passengers: "12",
    vehicleType: "van",
    pickupLocation: "Madinah Airport",
    dropoffLocation: "Masjid an-Nabawi",
    specialRequirements: "Need child seats for 2 children",
    status: "pending",
    amount: "SAR 450",
    createdAt: "2023-11-14T09:15:00Z",
  },
]

const customers: Customer[] = [
  {
    id: "C-1001",
    name: "Ahmed Al-Farsi",
    email: "ahmed@example.com",
    phone: "+966 50 123 4567",
    totalBookings: 5,
    lastBookingDate: "2023-11-15",
    status: "active",
  },
  {
    id: "C-1002",
    name: "Fatima Rahman",
    email: "fatima@example.com",
    phone: "+966 50 987 6543",
    totalBookings: 3,
    lastBookingDate: "2023-11-15",
    status: "active",
  },
  {
    id: "C-1003",
    name: "Muhammad Yusuf",
    email: "muhammad@example.com",
    phone: "+966 55 456 7890",
    totalBookings: 1,
    lastBookingDate: "2023-11-16",
    status: "new",
  },
]

const vehicles: Vehicle[] = [
  {
    id: "V-1001",
    name: "Toyota Camry",
    type: "Luxury Sedan",
    licensePlate: "KSA 1234",
    status: "available",
    driver: "Khalid Al-Otaibi",
    location: "Jeddah Airport",
    lastService: "2023-10-15",
    nextService: "2023-12-15",
    fuelLevel: 85,
  },
  {
    id: "V-1002",
    name: "Ford Taurus",
    type: "Luxury Sedan",
    licensePlate: "KSA 5678",
    status: "in-use",
    driver: "Abdullah Al-Faisal",
    location: "Makkah",
    lastService: "2023-09-20",
    nextService: "2023-11-20",
    fuelLevel: 65,
  },
  {
    id: "V-1003",
    name: "Hyundai Staria",
    type: "Premium Van",
    licensePlate: "KSA 9012",
    status: "maintenance",
    lastService: "2023-11-01",
    nextService: "2024-01-01",
    fuelLevel: 30,
  },
]

const drivers: Driver[] = [
  {
    id: "D-1001",
    name: "Khalid Al-Otaibi",
    status: "active",
    completedTrips: 128,
    rating: 4.9,
    vehicle: "Toyota Camry",
  },
  {
    id: "D-1002",
    name: "Abdullah Al-Faisal",
    status: "active",
    completedTrips: 112,
    rating: 4.8,
    vehicle: "Ford Taurus",
  },
  {
    id: "D-1003",
    name: "Mohammed Rahman",
    status: "idle",
    completedTrips: 95,
    rating: 4.7,
    vehicle: "Hyundai Staria",
  },
]

// Server actions for data operations
export async function createBooking(formData: FormData) {
  try {
    // Generate a new booking ID
    const bookingId = `B-${1000 + bookings.length + 1}`

    // Extract form data
    const customerName = formData.get("name") as string
    const customerEmail = formData.get("email") as string
    const customerPhone = formData.get("phone") as string
    const date = formData.get("date") as string
    const time = formData.get("time") || "09:00 AM"
    const passengers = formData.get("passengers") as string
    const vehicleType = formData.get("vehicleType") as string
    const pickupLocation = formData.get("pickupLocation") as string
    const dropoffLocation = formData.get("dropoffLocation") as string
    const specialRequirements = (formData.get("specialRequirements") as string) || ""

    // Calculate estimated amount based on vehicle type
    let amount = "SAR 200"
    if (vehicleType === "suv") amount = "SAR 350"
    if (vehicleType === "van") amount = "SAR 600"
    if (vehicleType === "bus") amount = "SAR 1200"

    // Create new booking
    const newBooking: Booking = {
      id: bookingId,
      customerName,
      customerEmail,
      customerPhone,
      date,
      time: time as string,
      passengers,
      vehicleType,
      pickupLocation,
      dropoffLocation,
      specialRequirements,
      status: "pending",
      amount,
      createdAt: new Date().toISOString(),
    }

    // Add to bookings array
    bookings.unshift(newBooking)

    // Check if customer exists, if not create a new customer
    const existingCustomer = customers.find((c) => c.email === customerEmail)

    if (existingCustomer) {
      // Update existing customer
      existingCustomer.totalBookings += 1
      existingCustomer.lastBookingDate = date
      if (existingCustomer.status === "new" && existingCustomer.totalBookings > 1) {
        existingCustomer.status = "active"
      }
    } else {
      // Create new customer
      const customerId = `C-${1000 + customers.length + 1}`
      const newCustomer: Customer = {
        id: customerId,
        name: customerName,
        email: customerEmail,
        phone: customerPhone,
        totalBookings: 1,
        lastBookingDate: date,
        status: "new",
      }
      customers.push(newCustomer)
    }

    // Revalidate paths to update UI
    revalidatePath("/admin")
    revalidatePath("/admin/bookings")
    revalidatePath("/booking")

    return { success: true, booking: newBooking }
  } catch (error) {
    console.error("Error creating booking:", error)
    return { success: false, error: "Failed to create booking" }
  }
}

export async function getBookings() {
  // In a real app, this would fetch from a database
  return bookings
}

export async function getBookingById(id: string) {
  return bookings.find((booking) => booking.id === id)
}

export async function updateBookingStatus(id: string, status: BookingStatus) {
  const booking = bookings.find((b) => b.id === id)
  if (booking) {
    booking.status = status
    revalidatePath("/admin")
    revalidatePath("/admin/bookings")
    return { success: true }
  }
  return { success: false, error: "Booking not found" }
}

export async function assignDriverToBooking(bookingId: string, driverId: string) {
  const booking = bookings.find((b) => b.id === bookingId)
  if (booking) {
    booking.driverId = driverId
    booking.status = "confirmed"
    revalidatePath("/admin")
    revalidatePath("/admin/bookings")
    return { success: true }
  }
  return { success: false, error: "Booking not found" }
}

export async function getCustomers() {
  return customers
}

export async function getVehicles() {
  return vehicles
}

export async function updateVehicleStatus(id: string, status: Vehicle["status"]) {
  const vehicle = vehicles.find((v) => v.id === id)
  if (vehicle) {
    vehicle.status = status
    revalidatePath("/admin")
    revalidatePath("/admin/fleet")
    return { success: true }
  }
  return { success: false, error: "Vehicle not found" }
}

export async function getDrivers() {
  return drivers
}

export async function getDashboardStats() {
  return {
    totalBookings: bookings.length,
    activeRides: bookings.filter((b) => b.status === "in-progress").length,
    totalRevenue: "SAR 284,521", // In a real app, this would be calculated
    customerSatisfaction: "4.8/5",
    bookingStatus: {
      completed: bookings.filter((b) => b.status === "completed").length,
      inProgress: bookings.filter((b) => b.status === "in-progress").length,
      pending: bookings.filter((b) => b.status === "pending").length,
      cancelled: bookings.filter((b) => b.status === "cancelled").length,
    },
    vehicleAvailability: {
      available: vehicles.filter((v) => v.status === "available").length,
      inUse: vehicles.filter((v) => v.status === "in-use").length,
      maintenance: vehicles.filter((v) => v.status === "maintenance").length,
      inactive: vehicles.filter((v) => v.status === "inactive").length,
    },
  }
}

